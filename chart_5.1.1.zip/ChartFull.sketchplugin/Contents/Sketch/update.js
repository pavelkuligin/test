var that = this;
function __skpm_run (key, context) {
  that.context = context;

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/update.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/@skpm/timers/immediate.js":
/*!************************************************!*\
  !*** ./node_modules/@skpm/timers/immediate.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* globals coscript, sketch */
var timeout = __webpack_require__(/*! ./timeout */ "./node_modules/@skpm/timers/timeout.js")

function setImmediate(func, param1, param2, param3, param4, param5, param6, param7, param8, param9, param10) {
  return timeout.setTimeout(func, 0, param1, param2, param3, param4, param5, param6, param7, param8, param9, param10)
}

function clearImmediate(id) {
  return timeout.clearTimeout(id)
}

module.exports = {
  setImmediate: setImmediate,
  clearImmediate: clearImmediate
}


/***/ }),

/***/ "./node_modules/@skpm/timers/test-if-fiber.js":
/*!****************************************************!*\
  !*** ./node_modules/@skpm/timers/test-if-fiber.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = function () {
  return typeof coscript !== 'undefined' && coscript.createFiber
}


/***/ }),

/***/ "./node_modules/@skpm/timers/timeout.js":
/*!**********************************************!*\
  !*** ./node_modules/@skpm/timers/timeout.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* globals coscript, sketch */
var fiberAvailable = __webpack_require__(/*! ./test-if-fiber */ "./node_modules/@skpm/timers/test-if-fiber.js")

var setTimeout
var clearTimeout

var fibers = []

if (fiberAvailable()) {
  var fibers = []

  setTimeout = function (func, delay, param1, param2, param3, param4, param5, param6, param7, param8, param9, param10) {
    // fibers takes care of keeping coscript around
    var id = fibers.length
    fibers.push(coscript.scheduleWithInterval_jsFunction(
      (delay || 0) / 1000,
      function () {
        func(param1, param2, param3, param4, param5, param6, param7, param8, param9, param10)
      }
    ))
    return id
  }

  clearTimeout = function (id) {
    var timeout = fibers[id]
    if (timeout) {
      timeout.cancel() // fibers takes care of keeping coscript around
      fibers[id] = undefined // garbage collect the fiber
    }
  }
} else {
  setTimeout = function (func, delay, param1, param2, param3, param4, param5, param6, param7, param8, param9, param10) {
    coscript.shouldKeepAround = true
    var id = fibers.length
    fibers.push(true)
    coscript.scheduleWithInterval_jsFunction(
      (delay || 0) / 1000,
      function () {
        if (fibers[id]) { // if not cleared
          func(param1, param2, param3, param4, param5, param6, param7, param8, param9, param10)
        }
        clearTimeout(id)
        if (fibers.every(function (_id) { return !_id })) { // if everything is cleared
          coscript.shouldKeepAround = false
        }
      }
    )
    return id
  }

  clearTimeout = function (id) {
    fibers[id] = false
  }
}

module.exports = {
  setTimeout: setTimeout,
  clearTimeout: clearTimeout
}


/***/ }),

/***/ "./node_modules/cocoascript-class/lib/index.js":
/*!*****************************************************!*\
  !*** ./node_modules/cocoascript-class/lib/index.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SuperCall = undefined;
exports.default = ObjCClass;

var _runtime = __webpack_require__(/*! ./runtime.js */ "./node_modules/cocoascript-class/lib/runtime.js");

exports.SuperCall = _runtime.SuperCall;

// super when returnType is id and args are void
// id objc_msgSendSuper(struct objc_super *super, SEL op, void)

const SuperInit = (0, _runtime.SuperCall)(NSStringFromSelector("init"), [], { type: "@" });

// Returns a real ObjC class. No need to use new.
function ObjCClass(defn) {
  const superclass = defn.superclass || NSObject;
  const className = (defn.className || defn.classname || "ObjCClass") + NSUUID.UUID().UUIDString();
  const reserved = new Set(['className', 'classname', 'superclass']);
  var cls = MOClassDescription.allocateDescriptionForClassWithName_superclass_(className, superclass);
  // Add each handler to the class description
  const ivars = [];
  for (var key in defn) {
    const v = defn[key];
    if (typeof v == 'function' && key !== 'init') {
      var selector = NSSelectorFromString(key);
      cls.addInstanceMethodWithSelector_function_(selector, v);
    } else if (!reserved.has(key)) {
      ivars.push(key);
      cls.addInstanceVariableWithName_typeEncoding(key, "@");
    }
  }

  cls.addInstanceMethodWithSelector_function_(NSSelectorFromString('init'), function () {
    const self = SuperInit.call(this);
    ivars.map(name => {
      Object.defineProperty(self, name, {
        get() {
          return getIvar(self, name);
        },
        set(v) {
          (0, _runtime.object_setInstanceVariable)(self, name, v);
        }
      });
      self[name] = defn[name];
    });
    // If there is a passsed-in init funciton, call it now.
    if (typeof defn.init == 'function') defn.init.call(this);
    return self;
  });

  return cls.registerClass();
};

function getIvar(obj, name) {
  const retPtr = MOPointer.new();
  (0, _runtime.object_getInstanceVariable)(obj, name, retPtr);
  return retPtr.value().retain().autorelease();
}

/***/ }),

/***/ "./node_modules/cocoascript-class/lib/runtime.js":
/*!*******************************************************!*\
  !*** ./node_modules/cocoascript-class/lib/runtime.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SuperCall = SuperCall;
exports.CFunc = CFunc;
const objc_super_typeEncoding = '{objc_super="receiver"@"super_class"#}';

// You can store this to call your function. this must be bound to the current instance.
function SuperCall(selector, argTypes, returnType) {
  const func = CFunc("objc_msgSendSuper", [{ type: '^' + objc_super_typeEncoding }, { type: ":" }, ...argTypes], returnType);
  return function (...args) {
    const struct = make_objc_super(this, this.superclass());
    const structPtr = MOPointer.alloc().initWithValue_(struct);
    return func(structPtr, selector, ...args);
  };
}

// Recursively create a MOStruct
function makeStruct(def) {
  if (typeof def !== 'object' || Object.keys(def).length == 0) {
    return def;
  }
  const name = Object.keys(def)[0];
  const values = def[name];

  const structure = MOStruct.structureWithName_memberNames_runtime(name, Object.keys(values), Mocha.sharedRuntime());

  Object.keys(values).map(member => {
    structure[member] = makeStruct(values[member]);
  });

  return structure;
}

function make_objc_super(self, cls) {
  return makeStruct({
    objc_super: {
      receiver: self,
      super_class: cls
    }
  });
}

// Due to particularities of the JS bridge, we can't call into MOBridgeSupport objects directly
// But, we can ask key value coding to do the dirty work for us ;)
function setKeys(o, d) {
  const funcDict = NSMutableDictionary.dictionary();
  funcDict.o = o;
  Object.keys(d).map(k => funcDict.setValue_forKeyPath(d[k], "o." + k));
}

// Use any C function, not just ones with BridgeSupport
function CFunc(name, args, retVal) {
  function makeArgument(a) {
    if (!a) return null;
    const arg = MOBridgeSupportArgument.alloc().init();
    setKeys(arg, {
      type64: a.type
    });
    return arg;
  }
  const func = MOBridgeSupportFunction.alloc().init();
  setKeys(func, {
    name: name,
    arguments: args.map(makeArgument),
    returnValue: makeArgument(retVal)
  });
  return func;
}

/*
@encode(char*) = "*"
@encode(id) = "@"
@encode(Class) = "#"
@encode(void*) = "^v"
@encode(CGRect) = "{CGRect={CGPoint=dd}{CGSize=dd}}"
@encode(SEL) = ":"
*/

function addStructToBridgeSupport(key, structDef) {
  // OK, so this is probably the nastiest hack in this file.
  // We go modify MOBridgeSupportController behind its back and use kvc to add our own definition
  // There isn't another API for this though. So the only other way would be to make a real bridgesupport file.
  const symbols = MOBridgeSupportController.sharedController().valueForKey('symbols');
  if (!symbols) throw Error("Something has changed within bridge support so we can't add our definitions");
  // If someone already added this definition, don't re-register it.
  if (symbols[key] !== null) return;
  const def = MOBridgeSupportStruct.alloc().init();
  setKeys(def, {
    name: key,
    type: structDef.type
  });
  symbols[key] = def;
};

// This assumes the ivar is an object type. Return value is pretty useless.
const object_getInstanceVariable = exports.object_getInstanceVariable = CFunc("object_getInstanceVariable", [{ type: "@" }, { type: '*' }, { type: "^@" }], { type: "^{objc_ivar=}" });
// Again, ivar is of object type
const object_setInstanceVariable = exports.object_setInstanceVariable = CFunc("object_setInstanceVariable", [{ type: "@" }, { type: '*' }, { type: "@" }], { type: "^{objc_ivar=}" });

// We need Mocha to understand what an objc_super is so we can use it as a function argument
addStructToBridgeSupport('objc_super', { type: objc_super_typeEncoding });

/***/ }),

/***/ "./node_modules/promise-polyfill/lib/index.js":
/*!****************************************************!*\
  !*** ./node_modules/promise-polyfill/lib/index.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(setTimeout, setImmediate) {

/**
 * @this {Promise}
 */
function finallyConstructor(callback) {
  var constructor = this.constructor;
  return this.then(
    function(value) {
      return constructor.resolve(callback()).then(function() {
        return value;
      });
    },
    function(reason) {
      return constructor.resolve(callback()).then(function() {
        return constructor.reject(reason);
      });
    }
  );
}

// Store setTimeout reference so promise-polyfill will be unaffected by
// other code modifying setTimeout (like sinon.useFakeTimers())
var setTimeoutFunc = setTimeout;

function noop() {}

// Polyfill for Function.prototype.bind
function bind(fn, thisArg) {
  return function() {
    fn.apply(thisArg, arguments);
  };
}

/**
 * @constructor
 * @param {Function} fn
 */
function Promise(fn) {
  if (!(this instanceof Promise))
    throw new TypeError('Promises must be constructed via new');
  if (typeof fn !== 'function') throw new TypeError('not a function');
  /** @type {!number} */
  this._state = 0;
  /** @type {!boolean} */
  this._handled = false;
  /** @type {Promise|undefined} */
  this._value = undefined;
  /** @type {!Array<!Function>} */
  this._deferreds = [];

  doResolve(fn, this);
}

function handle(self, deferred) {
  while (self._state === 3) {
    self = self._value;
  }
  if (self._state === 0) {
    self._deferreds.push(deferred);
    return;
  }
  self._handled = true;
  Promise._immediateFn(function() {
    var cb = self._state === 1 ? deferred.onFulfilled : deferred.onRejected;
    if (cb === null) {
      (self._state === 1 ? resolve : reject)(deferred.promise, self._value);
      return;
    }
    var ret;
    try {
      ret = cb(self._value);
    } catch (e) {
      reject(deferred.promise, e);
      return;
    }
    resolve(deferred.promise, ret);
  });
}

function resolve(self, newValue) {
  try {
    // Promise Resolution Procedure: https://github.com/promises-aplus/promises-spec#the-promise-resolution-procedure
    if (newValue === self)
      throw new TypeError('A promise cannot be resolved with itself.');
    if (
      newValue &&
      (typeof newValue === 'object' || typeof newValue === 'function')
    ) {
      var then = newValue.then;
      if (newValue instanceof Promise) {
        self._state = 3;
        self._value = newValue;
        finale(self);
        return;
      } else if (typeof then === 'function') {
        doResolve(bind(then, newValue), self);
        return;
      }
    }
    self._state = 1;
    self._value = newValue;
    finale(self);
  } catch (e) {
    reject(self, e);
  }
}

function reject(self, newValue) {
  self._state = 2;
  self._value = newValue;
  finale(self);
}

function finale(self) {
  if (self._state === 2 && self._deferreds.length === 0) {
    Promise._immediateFn(function() {
      if (!self._handled) {
        Promise._unhandledRejectionFn(self._value);
      }
    });
  }

  for (var i = 0, len = self._deferreds.length; i < len; i++) {
    handle(self, self._deferreds[i]);
  }
  self._deferreds = null;
}

/**
 * @constructor
 */
function Handler(onFulfilled, onRejected, promise) {
  this.onFulfilled = typeof onFulfilled === 'function' ? onFulfilled : null;
  this.onRejected = typeof onRejected === 'function' ? onRejected : null;
  this.promise = promise;
}

/**
 * Take a potentially misbehaving resolver function and make sure
 * onFulfilled and onRejected are only called once.
 *
 * Makes no guarantees about asynchrony.
 */
function doResolve(fn, self) {
  var done = false;
  try {
    fn(
      function(value) {
        if (done) return;
        done = true;
        resolve(self, value);
      },
      function(reason) {
        if (done) return;
        done = true;
        reject(self, reason);
      }
    );
  } catch (ex) {
    if (done) return;
    done = true;
    reject(self, ex);
  }
}

Promise.prototype['catch'] = function(onRejected) {
  return this.then(null, onRejected);
};

Promise.prototype.then = function(onFulfilled, onRejected) {
  // @ts-ignore
  var prom = new this.constructor(noop);

  handle(this, new Handler(onFulfilled, onRejected, prom));
  return prom;
};

Promise.prototype['finally'] = finallyConstructor;

Promise.all = function(arr) {
  return new Promise(function(resolve, reject) {
    if (!arr || typeof arr.length === 'undefined')
      throw new TypeError('Promise.all accepts an array');
    var args = Array.prototype.slice.call(arr);
    if (args.length === 0) return resolve([]);
    var remaining = args.length;

    function res(i, val) {
      try {
        if (val && (typeof val === 'object' || typeof val === 'function')) {
          var then = val.then;
          if (typeof then === 'function') {
            then.call(
              val,
              function(val) {
                res(i, val);
              },
              reject
            );
            return;
          }
        }
        args[i] = val;
        if (--remaining === 0) {
          resolve(args);
        }
      } catch (ex) {
        reject(ex);
      }
    }

    for (var i = 0; i < args.length; i++) {
      res(i, args[i]);
    }
  });
};

Promise.resolve = function(value) {
  if (value && typeof value === 'object' && value.constructor === Promise) {
    return value;
  }

  return new Promise(function(resolve) {
    resolve(value);
  });
};

Promise.reject = function(value) {
  return new Promise(function(resolve, reject) {
    reject(value);
  });
};

Promise.race = function(values) {
  return new Promise(function(resolve, reject) {
    for (var i = 0, len = values.length; i < len; i++) {
      values[i].then(resolve, reject);
    }
  });
};

// Use polyfill for setImmediate for performance gains
Promise._immediateFn =
  (typeof setImmediate === 'function' &&
    function(fn) {
      setImmediate(fn);
    }) ||
  function(fn) {
    setTimeoutFunc(fn, 0);
  };

Promise._unhandledRejectionFn = function _unhandledRejectionFn(err) {
  if (typeof console !== 'undefined' && console) {
    console.warn('Possible Unhandled Promise Rejection:', err); // eslint-disable-line no-console
  }
};

module.exports = Promise;

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/timers/timeout.js */ "./node_modules/@skpm/timers/timeout.js")["setTimeout"], __webpack_require__(/*! ./node_modules/@skpm/timers/immediate.js */ "./node_modules/@skpm/timers/immediate.js")["setImmediate"]))

/***/ }),

/***/ "./node_modules/sketch-polyfill-fetch/lib/index.js":
/*!*********************************************************!*\
  !*** ./node_modules/sketch-polyfill-fetch/lib/index.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Promise) {/* globals NSJSONSerialization NSJSONWritingPrettyPrinted NSDictionary NSHTTPURLResponse NSString NSASCIIStringEncoding NSUTF8StringEncoding coscript NSURL NSMutableURLRequest NSMutableData NSURLConnection */
var _ObjCClass = __webpack_require__(/*! cocoascript-class */ "./node_modules/cocoascript-class/lib/index.js")

var ObjCClass = _ObjCClass.default
var Buffer
try {
  Buffer = __webpack_require__(/*! buffer */ "buffer").Buffer
} catch (err) {}

function response (httpResponse, data) {
  var keys = []
  var all = []
  var headers = {}
  var header

  for (var i = 0; i < httpResponse.allHeaderFields().allKeys().length; i++) {
    var key = httpResponse.allHeaderFields().allKeys()[i].toLowerCase()
    var value = String(httpResponse.allHeaderFields()[key])
    keys.push(key)
    all.push([key, value])
    header = headers[key]
    headers[key] = header ? (header + ',' + value) : value
  }

  return {
    ok: (httpResponse.statusCode() / 200 | 0) == 1, // 200-399
    status: Number(httpResponse.statusCode()),
    statusText: NSHTTPURLResponse.localizedStringForStatusCode(httpResponse.statusCode()),
    useFinalURL: true,
    url: String(httpResponse.URL().absoluteString()),
    clone: response.bind(this, httpResponse, data),
    text: function () {
      return new Promise(function (resolve, reject) {
        const str = NSString.alloc().initWithData_encoding(data, NSASCIIStringEncoding)
        if (str) {
          resolve(str)
        } else {
          reject(new Error("Couldn't parse body"))
        }
      })
    },
    json: function () {
      return new Promise(function (resolve, reject) {
        var str = NSString.alloc().initWithData_encoding(data, NSUTF8StringEncoding)
        if (str) {
          // parse errors are turned into exceptions, which cause promise to be rejected
          var obj = JSON.parse(str)
          resolve(obj)
        } else {
          reject(new Error('Could not parse JSON because it is not valid UTF-8 data.'))
        }
      })
    },
    blob: function () {
      return Promise.resolve(data)
    },
    arrayBuffer: function() {
      return Promise.resolve(Buffer.from(data))
    },
    headers: {
      keys: function () { return keys },
      entries: function () { return all },
      get: function (n) { return headers[n.toLowerCase()] },
      has: function (n) { return n.toLowerCase() in headers }
    }
  }
}

// We create one ObjC class for ourselves here
var DelegateClass

function fetch (urlString, options) {
  options = options || {}
  var fiber
  try {
    fiber = coscript.createFiber()
  } catch (err) {
    coscript.shouldKeepAround = true
  }
  return new Promise(function (resolve, reject) {
    var url = NSURL.alloc().initWithString(urlString)
    var request = NSMutableURLRequest.requestWithURL(url)
    request.setHTTPMethod(options.method || 'GET')

    Object.keys(options.headers || {}).forEach(function (i) {
      request.setValue_forHTTPHeaderField(options.headers[i], i)
    })

    if (options.body) {
      var data
      if (typeof options.body === 'string') {
        var str = NSString.alloc().initWithString(options.body)
        data = str.dataUsingEncoding(NSUTF8StringEncoding)
      } else if (Buffer && Buffer.isBuffer(options.body)) {
        data = options.body.toNSData()
      } else if (options.body.isKindOfClass && (options.body.isKindOfClass(NSData) == 1) ) {
        data = options.body
      } else {
        var error
        data = NSJSONSerialization.dataWithJSONObject_options_error(options.body, NSJSONWritingPrettyPrinted, error)
        if (error != null) {
          return reject(error)
        }
        request.setValue_forHTTPHeaderField('' + data.length(), 'Content-Length')
      }
      request.setHTTPBody(data)
    }

    if (options.cache) {
      switch (options.cache) {
        case 'reload':
        case 'no-cache':
        case 'no-store': {
          request.setCachePolicy(1) // NSURLRequestReloadIgnoringLocalCacheData
        }
        case 'force-cache': {
          request.setCachePolicy(2) // NSURLRequestReturnCacheDataElseLoad
        }
        case 'only-if-cached': {
          request.setCachePolicy(3) // NSURLRequestReturnCacheDataElseLoad
        }
      }
    }


    if (!options.credentials) {
      request.setHTTPShouldHandleCookies(false)
    }

    if (!DelegateClass) {
      DelegateClass = ObjCClass({
        classname: 'FetchPolyfillDelegate',
        data: null,
        httpResponse: null,
        fiber: null,
        callbacks: null,

        'connectionDidFinishLoading:': function (connection) {
          this.callbacks.succeed(this.httpResponse, this.data)
          if (this.fiber) {
            this.fiber.cleanup()
          } else {
            coscript.shouldKeepAround = false
          }
        },
        'connection:didReceiveResponse:': function (connection, httpResponse) {
          this.httpResponse = httpResponse
          this.data = NSMutableData.alloc().init()
        },
        'connection:didFailWithError:': function (connection, error) {
          this.callbacks.fail(error)
          if (this.fiber) {
            this.fiber.cleanup()
          } else {
            coscript.shouldKeepAround = false
          }
        },
        'connection:didReceiveData:': function (connection, data) {
          this.data.appendData(data)
        }
      })
    }

    var finished = false

    function succeed(res, data) {
      finished = true
      resolve(response(res, data))
    }

    function fail(err) {
      finished = true
      reject(err)
    }

    var connectionDelegate = DelegateClass.new()
    connectionDelegate.callbacks = NSDictionary.dictionaryWithDictionary({
      succeed: succeed,
      fail: fail,
    })
    connectionDelegate.fiber = fiber;

    var connection = NSURLConnection.alloc().initWithRequest_delegate(
      request,
      connectionDelegate
    )

    if (fiber) {
      fiber.onCleanup(function () {
        if (!finished) {
          connection.cancel()
        }
      })
    }

  })
}

module.exports = fetch

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/promise-polyfill/lib/index.js */ "./node_modules/promise-polyfill/lib/index.js")))

/***/ }),

/***/ "./src/common.js":
/*!***********************!*\
  !*** ./src/common.js ***!
  \***********************/
/*! exports provided: checkSubscribtion, collectStats, defaultConf, getCanvas, chartUpdatable, moveToPoint, lineToPoint, curveToPoint, createOval, polarToCartesian, createNumGrid, createNumLabels, createGrid, createCandleGrid, createPlotGrid, createBarGrid, createHorizontalGrid, createLabels, createCandleLabels, createBarLabels, createHorizontalLabels, createPlotLabels, colorIndex, createRandomData, processData, processJSON, createLineChart, createDots, createAreaChart, createStackedAreaChart, createStreamGraph, createVerticalBarChart, createHorizontalBarChart, createGroupBarChart, createPieChart, createDonutChart, createProgressChart, createSparkline, createScatterPlot, createCandlestickChart */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(Promise, fetch) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "checkSubscribtion", function() { return checkSubscribtion; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "collectStats", function() { return collectStats; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "defaultConf", function() { return defaultConf; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCanvas", function() { return getCanvas; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "chartUpdatable", function() { return chartUpdatable; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "moveToPoint", function() { return moveToPoint; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "lineToPoint", function() { return lineToPoint; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "curveToPoint", function() { return curveToPoint; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createOval", function() { return createOval; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "polarToCartesian", function() { return polarToCartesian; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createNumGrid", function() { return createNumGrid; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createNumLabels", function() { return createNumLabels; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createGrid", function() { return createGrid; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createCandleGrid", function() { return createCandleGrid; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createPlotGrid", function() { return createPlotGrid; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createBarGrid", function() { return createBarGrid; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createHorizontalGrid", function() { return createHorizontalGrid; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createLabels", function() { return createLabels; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createCandleLabels", function() { return createCandleLabels; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createBarLabels", function() { return createBarLabels; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createHorizontalLabels", function() { return createHorizontalLabels; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createPlotLabels", function() { return createPlotLabels; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "colorIndex", function() { return colorIndex; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createRandomData", function() { return createRandomData; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "processData", function() { return processData; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "processJSON", function() { return processJSON; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createLineChart", function() { return createLineChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createDots", function() { return createDots; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createAreaChart", function() { return createAreaChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createStackedAreaChart", function() { return createStackedAreaChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createStreamGraph", function() { return createStreamGraph; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createVerticalBarChart", function() { return createVerticalBarChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createHorizontalBarChart", function() { return createHorizontalBarChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createGroupBarChart", function() { return createGroupBarChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createPieChart", function() { return createPieChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createDonutChart", function() { return createDonutChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createProgressChart", function() { return createProgressChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createSparkline", function() { return createSparkline; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createScatterPlot", function() { return createScatterPlot; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createCandlestickChart", function() { return createCandlestickChart; });
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

// return the status of subscription
function checkSubscribtion(status, email, lastCheck) {
  return new Promise(function (resolve) {
    var UI = __webpack_require__(/*! sketch/ui */ "sketch/ui"),
        Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings"),
        API = "https://api.gumroad.com/v2/products/mPhu9ohiu6ddjaUOUuQ8IQ==/subscribers?access_token=190c56c544530cf3e170a90141c87cf060d920a96f7f0c221d0ee63a06fbdc5d";

    function setPaySettings(JSON) {
      var subscribers = JSON.subscribers,
          count = 0;
      var isClient = subscribers.some(function (client) {
        if (client.email == email) {
          count += 1;
          var user_status = true,
              user_email = client.email,
              last_check = Date.now();
          Settings.setGlobalSettingForKey('user_status', user_status);
          Settings.setGlobalSettingForKey('user_email', user_email);
          Settings.setGlobalSettingForKey('last_check', last_check);
          return true;
        }

        return false;
      });

      if (isClient) {
        return true;
      }

      if (count == 0) {
        var user_status = false;
        Settings.setGlobalSettingForKey('user_status', user_status);
        return false;
      }
    }

    if (email == undefined) {
      UI.getInputFromUser("Email on Gumroad", {
        description: 'Enter email that you used to pay for Chart'
      }, function (err, value) {
        if (err) {
          resolve(false);
        } else {
          UI.message('Email saved in your account data');
          Settings.setGlobalSettingForKey('user_email', value);
          resolve(true);
        }
      });
    } else {
      var urlGumroad = API;
      fetch(urlGumroad).then(function (res) {
        return res.json();
      }).then(function (JSON) {
        var result = setPaySettings(JSON);
        resolve(result);
      });
    }
  });
} // collect stats

function collectStats(userId, email, appVersion, option, meta) {
  var date = Math.floor(Date.now() / 1000),
      stats = {
    "userId": userId,
    "email": email,
    "date": date,
    "app": "Chart",
    "appVersion": appVersion,
    "option": option,
    "platform": "Sketch",
    "meta": meta
  };
  fetch('https://chart.pavelkuligin.ru/collect', {
    method: 'POST',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    },
    body: stats
  }).then(function (res) {
    if (res.ok) {} else {}
  }).catch(function (error) {});
} // default configuration

function defaultConf() {
  var Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings");

  var conf = {
    "lineChart": {
      "colors": ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#e31a1c", "#fdbf6f", "#ff7f00", "#cab2d6", "#6a3d9a", "#ffff99", "#b15928"],
      "grid": "0",
      "labels": "0",
      "typeOfLine": "0",
      "dots": "0",
      "thickness": "2",
      "diameter": "8"
    },
    "areaChart": {
      "colors": ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#e31a1c", "#fdbf6f", "#ff7f00", "#cab2d6", "#6a3d9a", "#ffff99", "#b15928"],
      "grid": "0",
      "labels": "0",
      "typeOfLine": "0"
    },
    "stackedAreaChart": {
      "colors": ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#e31a1c", "#fdbf6f", "#ff7f00", "#cab2d6", "#6a3d9a", "#ffff99", "#b15928"],
      "grid": "0",
      "labels": "0",
      "typeOfLine": "0"
    },
    "streamGraph": {
      "colors": ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#e31a1c", "#fdbf6f", "#ff7f00", "#cab2d6", "#6a3d9a", "#ffff99", "#b15928"],
      "grid": "0",
      "labels": "0",
      "typeOfLine": "0"
    },
    "verticalBarChart": {
      "colors": ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#e31a1c", "#fdbf6f", "#ff7f00", "#cab2d6", "#6a3d9a", "#ffff99", "#b15928"],
      "grid": "0",
      "labels": "0",
      "barWidth": "0.2"
    },
    "horizontalBarChart": {
      "colors": ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#e31a1c", "#fdbf6f", "#ff7f00", "#cab2d6", "#6a3d9a", "#ffff99", "#b15928"],
      "grid": "0",
      "labels": "0",
      "barWidth": "0.2"
    },
    "groupBarChart": {
      "colors": ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#e31a1c", "#fdbf6f", "#ff7f00", "#cab2d6", "#6a3d9a", "#ffff99", "#b15928"],
      "grid": "0",
      "labels": "0",
      "barWidth": "1"
    },
    "pieChart": {
      "colors": ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#e31a1c", "#fdbf6f", "#ff7f00", "#cab2d6", "#6a3d9a", "#ffff99", "#b15928"],
      "sort": "0",
      "type": "0"
    },
    "donutChart": {
      "colors": ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#e31a1c", "#fdbf6f", "#ff7f00", "#cab2d6", "#6a3d9a", "#ffff99", "#b15928"],
      "sort": "0",
      "type": "0",
      "thickness": "30"
    },
    "progressChart": {
      "colors": ["#e31a1c"],
      "thickness": "10",
      "end": "0"
    },
    "sparkline": {
      "colors": ["#343434"],
      "thickness": "1",
      "diameter": "4"
    },
    "scatterPlot": {
      "colors": ["#1f78b4"],
      "grid": "0",
      "labels": "0",
      "diameter": "8"
    },
    "candlestickChart": {
      "colors": ["#33a02c", "#e31a1c"],
      "grid": "0",
      "labels": "0",
      "margin": "0.5"
    }
  };
  Settings.setGlobalSettingForKey('conf', JSON.stringify(conf));
} // function that returns all parameters of canvases

function getCanvas(context) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      UI = __webpack_require__(/*! sketch/ui */ "sketch/ui"),
      Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings"),
      doc = sketch.getSelectedDocument();

  var selection = doc.selectedLayers,
      canvasArr = new Array(),
      error = false,
      canvas;

  function isNumeric(n) {
    return !isNaN(parseFloat(n)) && isFinite(n);
  }

  if (selection.length > 0) {
    selection.forEach(function (layer) {
      var layerConf = Settings.layerSettingForKey(layer, 'localConf');

      if (layerConf == undefined && layer.type != "Group") {
        var startNum = isNumeric(layer.name) ? parseFloat(layer.name) : "false";
        layer.selected = false;
        canvas = {
          layer: layer,
          height: layer.frame.height,
          width: layer.frame.width,
          x: layer.frame.x,
          y: layer.frame.y,
          layerType: layer.shapeType,
          startNum: startNum,
          parent: layer.parent,
          conf: ""
        };
      } else {
        var parent = layer.parent,
            group = layer,
            newX = layer.frame.x,
            newY = layer.frame.y,
            oldCanvas = layer.layers[0],
            _startNum = isNumeric(layer.name) ? parseFloat(layer.name) : "false";

        layer.selected = false;

        if (layerConf == undefined) {
          layerConf = "";
        }

        parent.layers.push(oldCanvas);
        oldCanvas.frame.x = newX + oldCanvas.frame.x;
        oldCanvas.frame.y = newY + oldCanvas.frame.y;
        group.remove();
        canvas = {
          layer: oldCanvas,
          height: oldCanvas.frame.height,
          width: oldCanvas.frame.width,
          x: oldCanvas.frame.x,
          y: oldCanvas.frame.y,
          layerType: oldCanvas.shapeType,
          startNum: _startNum,
          parent: oldCanvas.parent,
          conf: layerConf
        };
      }

      canvasArr.push(canvas);
    });
  } else {
    UI.message('Select at least one layer or chart');
    error = true;
  }

  return [canvasArr, error];
}
function chartUpdatable(context) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      UI = __webpack_require__(/*! sketch/ui */ "sketch/ui"),
      Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings"),
      doc = sketch.getSelectedDocument();

  var selection = doc.selectedLayers,
      updatable = false;

  if (selection.length > 0) {
    selection.forEach(function (layer) {
      var layerConf = Settings.layerSettingForKey(layer, 'localConf');

      if (layerConf != undefined) {
        if (layerConf.data.selected == "random") {
          updatable = true;
        } else if (layerConf.data.selected == "table" && layerConf.data.csv.gsLink != null) {
          updatable = true;
        } else if (layerConf.data.selected == "json" && layerConf.data.json.jsonLink != null) {
          updatable = true;
        }
      }
    });
  } else {
    UI.message('Select at least one layer or chart');
  }

  return updatable;
} // Helper SVG functions

function moveToPoint(x, y) {
  return "M " + x + " " + y;
}
function lineToPoint(x, y) {
  return " L " + x + " " + y;
}
function curveToPoint(points) {
  return " C " + points.c1x + " " + points.c1y + " " + points.c2x + " " + points.c2y + " " + points.x + " " + points.y;
}
function createOval(cx, cy, r) {
  var oval = "M " + cx + " " + cy + " m -" + r + ", 0 a " + r + "," + r + " 0 1,0 " + r * 2 + ",0 a " + r + "," + r + " 0 1,0 -" + r * 2 + ",0";
  return oval;
}
function polarToCartesian(centerX, centerY, radius, angleInDegrees) {
  var angleInRadians = (angleInDegrees - 90) * Math.PI / 180.0;
  return {
    x: centerX + radius * Math.cos(angleInRadians),
    y: centerY + radius * Math.sin(angleInRadians)
  };
}
function createNumGrid(width, height, max, min, x0, y0, group, dir) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var minStepPx = 30,
      range = max - min,
      maxNumTicks = Math.floor(height / minStepPx),
      dividers = [1, 2, 5, 10],
      x1 = x0 + width,
      y1 = y0 + width,
      nullsCount,
      step,
      numLines;

  function numDigits(x) {
    return Math.max(Math.floor(Math.log10(Math.abs(x))), 0) + 1;
  }

  step = Math.floor(range / maxNumTicks);
  nullsCount = numDigits(step) - 1;

  for (var _i = 0; _i < dividers.length; _i++) {
    var _i2 = dividers[_i];
    step = _i2 * Math.pow(10, nullsCount);
    numLines = Math.floor(range / step);

    if (numLines * step <= range && numLines < maxNumTicks) {
      break;
    }
  }

  step = height / numLines;

  for (var i = 0; i < numLines + 1; i++) {
    var path = void 0;

    if (dir == "horizontal") {
      path = moveToPoint(x0, y0) + lineToPoint(x1, y0);
    } else {
      path = moveToPoint(x0, y0) + lineToPoint(x0, y1);
    }

    var gridLine = ShapePath.fromSVGPath(path);
    gridLine.style = {
      borders: [{
        color: "#F0F0F0",
        thickness: 1
      }]
    };
    gridLine.name = "Grid_" + (i + 1);
    group.layers.push(gridLine);

    if (dir == "horizontal") {
      y0 = y0 - step;
    } else {
      x0 = x0 + step;
    }
  }
}
function createNumLabels(width, height, max, min, x0, y0, group, dir, canvas) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      Text = sketch.Text,
      Rectangle = sketch.Rectangle;

  log(width + "px — " + height + "px; " + max + "—" + min);
  var minStepPx = 30,
      range = max - min,
      maxNumTicks = Math.floor(height / minStepPx),
      dividers = [1, 2, 5, 10],
      x1 = x0 + width,
      y1 = y0 + width,
      nullsCount,
      step,
      numLines,
      textStep,
      axisNum = min;

  function numDigits(x) {
    return Math.max(Math.floor(Math.log10(Math.abs(x))), 0) + 1;
  }

  step = Math.floor(range / maxNumTicks);
  nullsCount = numDigits(step) - 1;

  for (var _i3 = 0; _i3 < dividers.length; _i3++) {
    var _i4 = dividers[_i3];
    step = _i4 * Math.pow(10, nullsCount);
    numLines = Math.floor(range / step);

    if (numLines * step <= range && numLines < maxNumTicks) {
      break;
    }
  }

  textStep = step;
  step = height / numLines;

  for (var i = 0; i < numLines + 1; i++) {
    if (dir == "horizontal") {
      var text = new Text({
        fixedWidth: true,
        frame: new Rectangle(x0 - 60, y0 - step * i - 5, 50, 10),
        text: axisNum.toString(),
        style: {
          alignment: Text.Alignment.right,
          fontSize: 10,
          fontFamily: 'Helvetica',
          fontWeight: 5,
          kerning: 0,
          paragraphSpacing: 0,
          textTransform: "none",
          lineHeight: 10,
          fills: ['#a3a3a3'],
          borders: [{
            enabled: false
          }]
        }
      });
      group.layers.push(text);
      axisNum = axisNum + textStep;
    } else {
      var _text = new Text({
        fixedWidth: true,
        frame: new Rectangle(x0 - 15 + step * i, y0 + width + 10, 30, 10),
        text: axisNum.toString(),
        style: {
          alignment: Text.Alignment.center,
          fontSize: 10,
          fontFamily: 'Helvetica',
          fontWeight: 5,
          kerning: 0,
          paragraphSpacing: 0,
          textTransform: "none",
          lineHeight: 10,
          fills: ['#a3a3a3'],
          borders: [{
            enabled: false
          }]
        }
      });

      group.layers.push(_text);
      axisNum = axisNum + textStep;
    }
  }
}
function createGrid(conf, canvas, data, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  if (conf.grid.value == "1" || conf.grid.value == "3") {
    var minX = 60,
        Nx = data.columns - 1,
        y0x = canvas.y,
        y1x = y0x + canvas.height,
        x0x = canvas.x,
        stepNumX = Math.ceil(Nx / Math.floor(canvas.width / minX)),
        stepX = stepNumX * (canvas.width / Nx),
        numLinesX = Math.floor(Nx / stepNumX),
        Nz = Math.floor(data.columns / numLinesX),
        counter;

    for (var i = 0; i < numLinesX + 1; i++) {
      var path = moveToPoint(x0x, y0x) + lineToPoint(x0x, y1x),
          gridLine = ShapePath.fromSVGPath(path);
      gridLine.style = {
        borders: [{
          color: "#F0F0F0",
          thickness: 1
        }]
      };
      gridLine.name = "Grid_v_" + (i + 1);
      group.layers.push(gridLine);
      x0x = x0x + stepX;
      counter = i;
    }

    if (canvas.width > stepX * numLinesX) {
      var _path = moveToPoint(canvas.x + canvas.width, y0x) + lineToPoint(canvas.x + canvas.width, y1x),
          _gridLine = ShapePath.fromSVGPath(_path);

      _gridLine.style = {
        borders: [{
          color: "#F0F0F0",
          thickness: 1
        }]
      };
      _gridLine.name = "Grid_v_" + (counter + 1);
      group.layers.push(_gridLine);
    }
  }

  if (conf.grid.value == "1" || conf.grid.value == "2") {
    createNumGrid(canvas.width, canvas.height, data.niceMax, data.niceMin, canvas.x, canvas.y + canvas.height, group, "horizontal");
  }
}
function createCandleGrid(conf, canvas, data, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  if (conf.grid.value == "1" || conf.grid.value == "3") {
    var minX = 60,
        Nx = data.columns,
        y0x = canvas.y,
        y1x = y0x + canvas.height,
        x0x = canvas.x,
        step = canvas.width / data.columns / 2,
        stepNumX = Math.ceil(Nx / Math.floor(canvas.width / minX)),
        stepX = stepNumX * (canvas.width / Nx),
        numLinesX = Math.ceil(Nx / stepNumX),
        start = 0,
        num = 0;

    for (var i = 0; i < numLinesX + 1; i++) {
      var path = moveToPoint(x0x + start, y0x) + lineToPoint(x0x + start, y1x),
          gridLine = ShapePath.fromSVGPath(path);
      gridLine.style = {
        borders: [{
          color: "#F0F0F0",
          thickness: 1
        }]
      };
      gridLine.name = "Grid_v_" + (i + 1);
      group.layers.push(gridLine);
      start = stepX * i + step;
      num += i;
    }

    var pathEnd = moveToPoint(canvas.x + canvas.width, y0x) + lineToPoint(canvas.x + canvas.width, y1x),
        gridLineEnd = ShapePath.fromSVGPath(pathEnd);
    gridLineEnd.style = {
      borders: [{
        color: "#F0F0F0",
        thickness: 1
      }]
    };
    gridLineEnd.name = "Grid_v_" + (num + 1);
    group.layers.push(gridLineEnd);
  }

  if (conf.grid.value == "1" || conf.grid.value == "2") {
    createNumGrid(canvas.width, canvas.height, data.niceMax, data.niceMin, canvas.x, canvas.y + canvas.height, group, "horizontal");
  }
}
function createPlotGrid(conf, canvas, data, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  if (conf.grid.value == "1" || conf.grid.value == "3") {
    createNumGrid(canvas.height, canvas.width, data.xNiceMax, data.xNiceMin, canvas.x, canvas.y, group, "vertical");
  }

  if (conf.grid.value == "1" || conf.grid.value == "2") {
    createNumGrid(canvas.width, canvas.height, data.yNiceMax, data.yNiceMin, canvas.x, canvas.y + canvas.height, group, "horizontal");
  }
}
function createBarGrid(conf, canvas, data, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  if (conf.grid.value == "1" || conf.grid.value == "3") {
    var xStep = canvas.width / data.columns,
        x0x = canvas.x,
        y0x = canvas.y,
        y1x = canvas.y + canvas.height;

    for (var i = 0; i < data.columns + 1; i++) {
      var path = moveToPoint(x0x, y0x) + lineToPoint(x0x, y1x),
          gridLine = ShapePath.fromSVGPath(path);
      gridLine.style = {
        borders: [{
          color: "#F0F0F0",
          thickness: 1
        }]
      };
      gridLine.name = "Grid_v_" + (i + 1);
      group.layers.push(gridLine);
      x0x = x0x + xStep;
    }
  }

  if (conf.grid.value == "1" || conf.grid.value == "2") {
    createNumGrid(canvas.width, canvas.height, data.niceMax, data.niceMin, canvas.x, canvas.y + canvas.height, group, "horizontal");
  }
}
function createHorizontalGrid(conf, canvas, data, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  if (conf.grid.value == "1" || conf.grid.value == "3") {
    createNumGrid(canvas.height, canvas.width, data.niceMax, data.niceMin, canvas.x, canvas.y, group, "vertical");
  }

  if (conf.grid.value == "1" || conf.grid.value == "2") {
    var yStep = canvas.height / data.columns,
        y0x = canvas.y,
        x0x = canvas.x,
        x1x = canvas.x + canvas.width;

    for (var i = 0; i < data.columns + 1; i++) {
      var path = moveToPoint(x0x, y0x) + lineToPoint(x1x, y0x),
          gridLine = ShapePath.fromSVGPath(path);
      gridLine.style = {
        borders: [{
          color: "#F0F0F0",
          thickness: 1
        }]
      };
      gridLine.name = "Grid_v_" + (i + 1);
      group.layers.push(gridLine);
      y0x = y0x + yStep;
    }
  }
}
function createLabels(conf, canvas, data, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      Text = sketch.Text,
      Rectangle = sketch.Rectangle;

  if (conf.labels.value == "1" || conf.labels.value == "3") {
    var minX = 60,
        Nx = data.columns - 1,
        x0x = canvas.x,
        stepNumX = Math.ceil(Nx / Math.floor(canvas.width / minX)),
        stepX = stepNumX * (canvas.width / Nx),
        numLinesX = Math.floor(Nx / stepNumX),
        Nz = Math.floor(data.columns / numLinesX);

    for (var i = 0; i < numLinesX + 1; i++) {
      if (data.header != false) {
        var text = new Text({
          fixedWidth: true,
          frame: new Rectangle(x0x - 30, canvas.y + canvas.height + 10, 60, 10),
          text: data.header[i * Nz],
          style: {
            alignment: Text.Alignment.center,
            fontSize: 10,
            fontFamily: 'Helvetica',
            fontWeight: 5,
            kerning: 0,
            paragraphSpacing: 0,
            textTransform: "none",
            lineHeight: 10,
            fills: ['#a3a3a3'],
            borders: [{
              enabled: false
            }]
          }
        });
        group.layers.push(text);
      }

      x0x = x0x + stepX;
    }
  }

  if (conf.labels.value == "1" || conf.labels.value == "2") {
    createNumLabels(canvas.width, canvas.height, data.niceMax, data.niceMin, canvas.x, canvas.y + canvas.height, group, "horizontal", canvas);
  }
}
function createCandleLabels(conf, canvas, data, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      Text = sketch.Text,
      Rectangle = sketch.Rectangle;

  if (conf.labels.value == "1" || conf.labels.value == "3") {
    var minX = 60,
        Nx = data.columns,
        x0x = canvas.x,
        step = canvas.width / data.columns / 2,
        stepNumX = Math.ceil(Nx / Math.floor(canvas.width / minX)),
        stepX = stepNumX * (canvas.width / Nx),
        numLinesX = Math.ceil(Nx / stepNumX),
        Nz = Math.ceil(data.columns / numLinesX);

    for (var i = 0; i < numLinesX; i++) {
      if (data.header != false) {
        var text = new Text({
          fixedWidth: true,
          frame: new Rectangle(x0x + stepX * i + step - 30, canvas.y + canvas.height + 10, 60, 10),
          text: data.header[i * Nz],
          style: {
            alignment: Text.Alignment.center,
            fontSize: 10,
            fontFamily: 'Helvetica',
            fontWeight: 5,
            kerning: 0,
            paragraphSpacing: 0,
            textTransform: "none",
            lineHeight: 10,
            fills: ['#a3a3a3'],
            borders: [{
              enabled: false
            }]
          }
        });
        group.layers.push(text);
      }
    }
  }

  if (conf.labels.value == "1" || conf.labels.value == "2") {
    createNumLabels(canvas.width, canvas.height, data.niceMax, data.niceMin, canvas.x, canvas.y + canvas.height, group, "horizontal", canvas);
  }
}
function createBarLabels(conf, canvas, data, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      Text = sketch.Text,
      Rectangle = sketch.Rectangle;

  if (conf.labels.value == "1" || conf.labels.value == "3") {
    var xStep = canvas.width / data.columns,
        x0x = canvas.x + (xStep - 60) / 2;

    if (xStep >= 60) {
      for (var i = 0; i < data.columns; i++) {
        if (data.header != false) {
          var text = new Text({
            fixedWidth: true,
            frame: new Rectangle(x0x, canvas.y + canvas.height + 10, 60, 10),
            text: data.header[i],
            style: {
              alignment: Text.Alignment.center,
              fontSize: 10,
              fontFamily: 'Helvetica',
              fontWeight: 5,
              kerning: 0,
              paragraphSpacing: 0,
              textTransform: "none",
              lineHeight: 10,
              fills: ['#a3a3a3'],
              borders: [{
                enabled: false
              }]
            }
          });
          group.layers.push(text);
        }

        x0x = x0x + xStep;
      }
    } else {
      for (var _i5 = 0; _i5 < data.columns; _i5++) {
        if (data.header != false) {
          var _text2 = new Text({
            fixedWidth: true,
            frame: new Rectangle(x0x, canvas.y + canvas.height + 10, 60, 10),
            text: data.header[_i5],
            transform: {
              rotation: 90
            },
            style: {
              alignment: Text.Alignment.left,
              fontSize: 10,
              fontFamily: 'Helvetica',
              fontWeight: 5,
              kerning: 0,
              paragraphSpacing: 0,
              textTransform: "none",
              lineHeight: 10,
              fills: ['#a3a3a3'],
              borders: [{
                enabled: false
              }]
            }
          });

          _text2.frame.y = _text2.frame.y + 23;
          _text2.frame.x = _text2.frame.x - 2;
          group.layers.push(_text2);
        }

        x0x = x0x + xStep;
      }
    }
  }

  if (conf.labels.value == "1" || conf.labels.value == "2") {
    createNumLabels(canvas.width, canvas.height, data.niceMax, data.niceMin, canvas.x, canvas.y + canvas.height, group, "horizontal", canvas);
  }
}
function createHorizontalLabels(conf, canvas, data, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      Text = sketch.Text,
      Rectangle = sketch.Rectangle;

  if (conf.labels.value == "1" || conf.labels.value == "3") {
    createNumLabels(canvas.height, canvas.width, data.niceMax, data.niceMin, canvas.x, canvas.y, group, "vertical", canvas);
  }

  if (conf.labels.value == "1" || conf.labels.value == "2") {
    var yStep = canvas.height / data.columns,
        y0x = canvas.y + (yStep - 10) / 2;

    for (var i = 0; i < data.columns; i++) {
      if (data.header != false) {
        var text = new Text({
          fixedWidth: true,
          frame: new Rectangle(canvas.x - 70, y0x, 60, 10),
          text: data.header[i],
          style: {
            alignment: Text.Alignment.right,
            fontSize: 10,
            fontFamily: 'Helvetica',
            fontWeight: 5,
            kerning: 0,
            paragraphSpacing: 0,
            textTransform: "none",
            lineHeight: 10,
            fills: ['#a3a3a3'],
            borders: [{
              enabled: false
            }]
          }
        });
        group.layers.push(text);
      }

      y0x = y0x + yStep;
    }
  }
}
function createPlotLabels(conf, canvas, data, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      Text = sketch.Text,
      Rectangle = sketch.Rectangle;

  if (conf.labels.value == "1" || conf.labels.value == "3") {
    createNumLabels(canvas.height, canvas.width, data.xNiceMax, data.xNiceMin, canvas.x, canvas.y, group, "vertical");
  }

  if (conf.labels.value == "1" || conf.labels.value == "2") {
    createNumLabels(canvas.width, canvas.height, data.yNiceMax, data.yNiceMin, canvas.x, canvas.y + canvas.height, group, "horizontal");
  }
} // colorPalette index

function colorIndex(i, colorPalette) {
  var colorLength = colorPalette.length;

  if (i + 1 > colorLength) {
    var rest = (i + 1) % colorLength;

    if (rest == 0) {
      return colorLength - 1;
    } else {
      return rest - 1;
    }
  } else {
    return i;
  }
} // Create random data set

function createRandomData(rows, columns, min, max, distr, type) {
  var dataRow = new Array(),
      dataTable = new Array(),
      dataMax = new Array(),
      dataMin = new Array(),
      headers = [];

  function randNum(min, max, col) {
    min = Number(min);
    max = Number(max);
    col = Number(col);
    var data = new Array();

    for (var i = 0; i < col; i++) {
      data[i] = Number(Math.random() * (max - min) + min).toFixed(2);
    }

    return data;
  }

  function trendUp(min, max, col) {
    min = Number(min);
    max = Number(max);
    col = Number(col);
    var step = (max - min) / col,
        data = new Array();

    for (var i = 0; i < col; i++) {
      var tempNum = min + step * (Math.random() * (1.3 - 0.5) + 0.5);
      min += tempNum - min;
      data[i] = tempNum.toFixed(2);
    }

    return data;
  }

  function trendDown(min, max, col) {
    min = Number(min);
    max = Number(max);
    col = Number(col);
    var step = (max - min) / col,
        data = new Array();

    for (var i = 0; i < col; i++) {
      var tempNum = max - step * (Math.random() * (1.3 - 0.5) + 0.5);
      max -= max - tempNum;
      data[i] = tempNum.toFixed(2);
    }

    return data;
  }

  function normalDistr(min, max, col) {
    max = Number(max);
    min = Number(min);
    col = Number(col - 1);
    var data = new Array(),
        originalMax = max;

    for (var i = 0; i <= col; i++) {
      max = max * Math.random();
      var c = min,
          b = 4 * (max - min) / col,
          a = -b / col;
      var tempNum = a * Math.pow(i, 2) + b * i + c;
      data[i] = tempNum.toFixed(2);
      max = originalMax;
    }

    return data;
  }

  var funcArr = [randNum, trendUp, trendDown, normalDistr];

  if (type == "candle") {
    var newRandom = function newRandom(min, max) {
      return Math.random() * (max - min) + min;
    };

    var range = max - min,
        minTrend = min + newRandom(range * 0.1, range * 0.3),
        maxTrend = max - newRandom(range * 0.1, range * 0.3),
        trendStep = (maxTrend - minTrend) / columns,
        startUp = minTrend,
        startDown = maxTrend,
        centerPoint,
        high,
        close,
        open,
        low,
        delta,
        highArr = new Array(),
        closeArr = new Array(),
        openArr = new Array(),
        lowArr = new Array();

    for (var j = 0; j < columns; j++) {
      if (distr == "1") {
        // Up
        centerPoint = Number(startUp) + trendStep * newRandom(0.7, 1.3);
        startUp = centerPoint;
      } else if (distr == "2") {
        // Down
        centerPoint = Number(startDown) - trendStep * newRandom(0.7, 1.3);
        startDown = centerPoint;
      } else {
        // Noise
        centerPoint = newRandom(range * 0.1, range * 0.9);
      }

      high = centerPoint * newRandom(1.1, 1.3);
      low = centerPoint * newRandom(0.7, 0.9);
      delta = high - low;
      close = newRandom(Number(low) + 0.2 * delta, Number(high) - 0.2 * delta);

      if (close < high - (high - low) / 2) {
        var openDelta = high - close;
        open = newRandom(Number(close) + 0.2 * openDelta, Number(high) - 0.2 * openDelta);
      } else {
        var openDelta = close - low;
        open = newRandom(Number(low) + 0.2 * openDelta, Number(close) - 0.2 * openDelta);
      }

      highArr[j] = high.toFixed(0);
      closeArr[j] = close.toFixed(0);
      openArr[j] = open.toFixed(0);
      lowArr[j] = low.toFixed(0);
    }

    dataTable[0] = highArr;
    dataTable[1] = closeArr;
    dataTable[2] = openArr;
    dataTable[3] = lowArr;
  } else {
    for (var i = 0; i < rows; i++) {
      if (distr == "0") {
        dataRow = randNum(min, max, columns);
      } else if (distr == "1") {
        dataRow = trendUp(min, max, columns);
      } else if (distr == "2") {
        if (type == "scatterplot" && i == 0) {
          dataRow = trendUp(min, max, columns);
        } else {
          dataRow = trendDown(min, max, columns);
        }
      } else if (distr == "3") {
        if (type == "scatterplot" && i == 0) {
          dataRow = trendUp(min, max, columns);
        } else {
          dataRow = normalDistr(min, max, columns);
        }
      } else {
        var _randNum = Number(Math.random() * (funcArr.length - 1)).toFixed(0);

        dataRow = funcArr[_randNum](min, max, columns);
      }

      dataTable[i] = dataRow;
      dataMax[i] = Math.max.apply(Math, _toConsumableArray(dataRow));
      dataMin[i] = Math.min.apply(Math, _toConsumableArray(dataRow));
    }
  }

  for (var h = 0; h < columns; h++) {
    headers[h] = "Text";
  }

  var dataObj = {
    table: dataTable,
    max: Math.max.apply(Math, dataMax),
    min: Math.min.apply(Math, dataMin),
    rows: dataTable.length,
    columns: dataTable[0].length,
    header: headers
  };
  return dataObj;
} // Create data set from real data

function processData(data, headers) {
  function isNumeric(n) {
    return !isNaN(parseFloat(n)) && isFinite(n);
  }

  function tableMin(N) {
    var min = new Array();

    for (var i in N) {
      min[i] = Math.min.apply(Math, _toConsumableArray(N[i]));
    }

    return Math.min.apply(Math, min);
  }

  function tableMax(N) {
    var max = new Array();

    for (var i in N) {
      max[i] = Math.max.apply(Math, _toConsumableArray(N[i]));
    }

    return Math.max.apply(Math, max);
  }

  var col = data[0].length,
      row = data.length,
      newData = data,
      header;

  if (headers == true) {
    header = newData[0];
    newData.splice(0, 1);

    for (var i = 0; i < row - 1; i++) {
      for (var j = 0; j < col; j++) {
        newData[i][j] = parseFloat(newData[i][j].toString().replace(/[^\d.-]/g, ''));
      }
    }

    row = row - 1;
  } else {
    header = false;

    for (var _i6 = 0; _i6 < row; _i6++) {
      for (var _j = 0; _j < col; _j++) {
        newData[_i6][_j] = parseFloat(newData[_i6][_j].toString().replace(/[^\d.-]/g, ''));
      }
    }
  }

  var dataObj = {
    table: newData,
    rows: row,
    columns: col,
    min: tableMin(newData),
    max: tableMax(newData),
    header: header
  };
  return dataObj;
} // Create data set from JSON

function processJSON(JSON, rawKeys, rawHeader) {
  var keys = new Array(),
      headerKey = "",
      dataTable = new Array(),
      dataMax = new Array(),
      dataMin = new Array();

  function getValues(obj, key) {
    var objects = [];

    for (var i in obj) {
      if (!obj.hasOwnProperty(i)) continue;

      if (_typeof(obj[i]) == 'object') {
        objects = objects.concat(getValues(obj[i], key));
      } else if (i == key) {
        objects.push(obj[i]);
      }
    }

    return objects;
  }

  rawKeys.forEach(function (key) {
    if (key.checked == true) {
      keys.push(key.name);
    }
  });
  rawHeader.forEach(function (header) {
    if (key.checked == true) {
      headerKey = header.name;
    }
  });
  var headers = getValues(JSON, headerKey);

  for (var i in keys) {
    var row = getValues(JSON, keys[i]);

    for (var j in row) {
      row[j] = row[j].toString();
      row[j] = parseFloat(row[j].replace(/[^\d.-]/g, ''));
    }

    dataTable[i] = row;
    dataMax[i] = Math.max.apply(Math, _toConsumableArray(dataTable[i]));
    dataMin[i] = Math.min.apply(Math, _toConsumableArray(dataTable[i]));
  }

  var dataObj = {
    table: dataTable,
    max: Math.max.apply(Math, dataMax),
    min: Math.min.apply(Math, dataMin),
    rows: dataTable.length,
    columns: dataTable[0].length,
    header: headers
  };
  return dataObj;
} // Line chart

function createLineChart(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var x0 = canvas.x,
      y = 0,
      yAxe = data.niceMax - data.niceMin,
      zero = canvas.y + canvas.height,
      xStep = canvas.width / (data.columns - 1);
  var y0 = zero - canvas.height / yAxe * (Number(data.table[i][0]) - data.niceMin),
      xLast = x0,
      yLast = y0,
      xNext = 0,
      pathData = moveToPoint(x0, y0),
      m = 0,
      dx1 = 0,
      dy1 = 0,
      dx2 = 0,
      dy2 = 0,
      preP = {
    x: x0,
    y: y0
  },
      nexP = {},
      f = 0.3,
      t = 1;

  function gradient(a, b) {
    return (b.y - a.y) / (b.x - a.x);
  }

  for (var j = 1; j < data.columns; j++) {
    xNext = xLast + xStep;
    y = zero - canvas.height / yAxe * (Number(data.table[i][j]) - data.niceMin);
    var curP = {
      x: xNext,
      y: y
    };

    if (j == data.columns - 1) {
      dx2 = 0;
      dy2 = 0;
    } else {
      nexP = {
        x: xNext + xStep,
        y: zero - canvas.height / yAxe * (Number(data.table[i][j + 1]) - data.niceMin)
      };
      m = gradient(preP, nexP);
      dx2 = (nexP.x - curP.x) * -f;
      dy2 = dx2 * m * t;
    }

    if (conf.typeOfLines.value == "1") {
      pathData += lineToPoint(xNext, y);
    } else if (conf.typeOfLines.value == "0") {
      var points = {
        x: xNext,
        y: y,
        c1x: xLast + xStep / 2,
        c1y: yLast,
        c2x: xNext - xStep / 2,
        c2y: y
      };
      pathData += curveToPoint(points);
    } else {
      var _points = {
        x: curP.x,
        y: curP.y,
        c1x: preP.x - dx1,
        c1y: preP.y - dy1,
        c2x: curP.x + dx2,
        c2y: curP.y + dy2
      };
      pathData += curveToPoint(_points);
      dx1 = dx2;
      dy1 = dy2;
      preP = curP;
    }

    xLast = xNext;
    yLast = y;
  }

  var line = ShapePath.fromSVGPath(pathData);
  line.style = {
    borders: [{
      color: conf.colors[colorIndex(i, conf.colors)],
      thickness: conf.thicknessOfLines.value
    }]
  };
  line.name = "Line_" + (i + 1);
  group.layers.push(line);
}
function createDots(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var x = canvas.x,
      y = 0,
      yAxe = data.niceMax - data.niceMin,
      zero = canvas.y + canvas.height,
      xStep = canvas.width / (data.columns - 1),
      radius = conf.diameterOfDots.value / 2;

  for (var j = 0; j < data.columns; j++) {
    y = zero - canvas.height / yAxe * (Number(data.table[i][j]) - data.niceMin);
    var dot = ShapePath.fromSVGPath(createOval(x, y, radius));
    dot.name = "Dot_" + (i + 1) + (j + 1);

    if (conf.dots.value == "1") {
      dot.style = {
        fills: [conf.colors[colorIndex(i, conf.colors)]],
        borders: [{
          enabled: false
        }]
      };
    } else {
      dot.style = {
        fills: ["#fff"],
        borders: [{
          color: conf.colors[colorIndex(i, conf.colors)],
          thickness: conf.thicknessOfLines.value
        }]
      };
    }

    group.layers.push(dot);
    x = x + xStep;
  }
} // Area chart

function createAreaChart(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var x0 = canvas.x,
      y = 0,
      yAxe = data.niceMax - data.niceMin,
      zero = canvas.y + canvas.height,
      xStep = canvas.width / (data.columns - 1);
  var y0 = zero - canvas.height / yAxe * (Number(data.table[i][0]) - data.niceMin),
      xLast = x0,
      yLast = y0,
      xNext = 0,
      pathData = moveToPoint(x0, y0),
      m = 0,
      dx1 = 0,
      dy1 = 0,
      dx2 = 0,
      dy2 = 0,
      preP = {
    x: x0,
    y: y0
  },
      nexP = {},
      f = 0.3,
      t = 1;

  function gradient(a, b) {
    return (b.y - a.y) / (b.x - a.x);
  }

  for (var j = 1; j < data.columns; j++) {
    xNext = xLast + xStep;
    y = zero - canvas.height / yAxe * (Number(data.table[i][j]) - data.niceMin);
    var curP = {
      x: xNext,
      y: y
    };

    if (j == data.columns - 1) {
      dx2 = 0;
      dy2 = 0;
    } else {
      nexP = {
        x: xNext + xStep,
        y: zero - canvas.height / yAxe * (Number(data.table[i][j + 1]) - data.niceMin)
      };
      m = gradient(preP, nexP);
      dx2 = (nexP.x - curP.x) * -f;
      dy2 = dx2 * m * t;
    }

    if (conf.typeOfLines.value == "1") {
      pathData += lineToPoint(xNext, y);
    } else if (conf.typeOfLines.value == "0") {
      var points = {
        x: xNext,
        y: y,
        c1x: xLast + xStep / 2,
        c1y: yLast,
        c2x: xNext - xStep / 2,
        c2y: y
      };
      pathData += curveToPoint(points);
    } else {
      var _points2 = {
        x: curP.x,
        y: curP.y,
        c1x: preP.x - dx1,
        c1y: preP.y - dy1,
        c2x: curP.x + dx2,
        c2y: curP.y + dy2
      };
      pathData += curveToPoint(_points2);
      dx1 = dx2;
      dy1 = dy2;
      preP = curP;
    }

    xLast = xNext;
    yLast = y;
  }

  pathData += lineToPoint(canvas.x + canvas.width, zero);
  pathData += lineToPoint(canvas.x, zero);
  pathData += " Z";
  var area = ShapePath.fromSVGPath(pathData);
  area.style = {
    fills: [conf.colors[colorIndex(i, conf.colors)]],
    borders: [{
      enabled: false
    }],
    opacity: 0.8
  };
  area.name = "Area_" + (i + 1);
  group.layers.push(area);
} // Stacked area chart

function createStackedAreaChart(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var x0 = canvas.x,
      y = 0,
      yAxe = data.niceMax - data.niceMin,
      zero = canvas.y + canvas.height,
      xStep = canvas.width / (data.columns - 1);
  var y0 = zero - canvas.height / yAxe * (Number(data.table[i][0]) - data.niceMin),
      xLast = x0,
      yLast = y0,
      xNext = 0,
      pathData = moveToPoint(x0, y0),
      m = 0,
      dx1 = 0,
      dy1 = 0,
      dx2 = 0,
      dy2 = 0,
      preP = {
    x: x0,
    y: y0
  },
      nexP = {},
      f = 0.3,
      t = 1;

  function gradient(a, b) {
    return (b.y - a.y) / (b.x - a.x);
  }

  for (var j = 1; j < data.columns; j++) {
    xNext = xLast + xStep;
    y = zero - canvas.height / yAxe * (Number(data.table[i][j]) - data.niceMin);
    var curP = {
      x: xNext,
      y: y
    };

    if (j == data.columns - 1) {
      dx2 = 0;
      dy2 = 0;
    } else {
      nexP = {
        x: xNext + xStep,
        y: zero - canvas.height / yAxe * (Number(data.table[i][j + 1]) - data.niceMin)
      };
      m = gradient(preP, nexP);
      dx2 = (nexP.x - curP.x) * -f;
      dy2 = dx2 * m * t;
    }

    if (conf.typeOfLines.value == "1") {
      pathData += lineToPoint(xNext, y);
    } else if (conf.typeOfLines.value == "0") {
      var points = {
        x: xNext,
        y: y,
        c1x: xLast + xStep / 2,
        c1y: yLast,
        c2x: xNext - xStep / 2,
        c2y: y
      };
      pathData += curveToPoint(points);
    } else {
      var _points3 = {
        x: curP.x,
        y: curP.y,
        c1x: preP.x - dx1,
        c1y: preP.y - dy1,
        c2x: curP.x + dx2,
        c2y: curP.y + dy2
      };
      pathData += curveToPoint(_points3);
      dx1 = dx2;
      dy1 = dy2;
      preP = curP;
    }

    xLast = xNext;
    yLast = y;
  }

  var yPrev = zero - canvas.height / yAxe * (Number(data.table[i - 1][data.columns - 1]) - data.niceMin);
  pathData += lineToPoint(xLast, yPrev);
  yLast = yPrev;
  m = 0;
  dx1 = 0;
  dy1 = 0;
  dx2 = 0;
  dy2 = 0;
  preP = {
    x: xLast,
    y: yPrev
  };
  nexP = {};

  for (var _j2 = data.columns - 2; _j2 >= 0; _j2--) {
    xNext = xLast - xStep;
    y = zero - canvas.height / yAxe * (Number(data.table[i - 1][_j2]) - data.niceMin);
    var _curP = {
      x: xNext,
      y: y
    };

    if (_j2 == 0) {
      dx2 = 0;
      dy2 = 0;
    } else {
      nexP = {
        x: xNext - xStep,
        y: zero - canvas.height / yAxe * (Number(data.table[i - 1][_j2 - 1]) - data.niceMin)
      };
      m = gradient(preP, nexP);
      dx2 = (nexP.x - _curP.x) * -f;
      dy2 = dx2 * m * t;
    }

    if (conf.typeOfLines.value == "1") {
      pathData += lineToPoint(xNext, y);
    } else if (conf.typeOfLines.value == "0") {
      var _points4 = {
        x: xNext,
        y: y,
        c1x: xLast - xStep / 2,
        c1y: yLast,
        c2x: xNext + xStep / 2,
        c2y: y
      };
      pathData += curveToPoint(_points4);
    } else {
      var _points5 = {
        x: _curP.x,
        y: _curP.y,
        c1x: preP.x - dx1,
        c1y: preP.y - dy1,
        c2x: _curP.x + dx2,
        c2y: _curP.y + dy2
      };
      pathData += curveToPoint(_points5);
      dx1 = dx2;
      dy1 = dy2;
      preP = _curP;
    }

    xLast = xNext;
    yLast = y;
  }

  pathData += " Z";
  var stackedArea = ShapePath.fromSVGPath(pathData);
  stackedArea.style = {
    fills: [conf.colors[colorIndex(i - 1, conf.colors)]],
    borders: [{
      enabled: false
    }]
  };
  stackedArea.name = "Stacked_area_" + i;
  group.layers.push(stackedArea);
}
function createStreamGraph(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var x0 = canvas.x,
      y = 0,
      yAxe = data.niceMax - data.niceMin,
      zero = canvas.y + canvas.height,
      xStep = canvas.width / (data.columns - 1);
  var y0 = zero - canvas.height / yAxe * (Number(data.table[i][0]) - data.niceMin),
      xLast = x0,
      yLast = y0,
      xNext = 0,
      pathData = moveToPoint(x0, y0),
      m = 0,
      dx1 = 0,
      dy1 = 0,
      dx2 = 0,
      dy2 = 0,
      preP = {
    x: x0,
    y: y0
  },
      nexP = {},
      f = 0.3,
      t = 1;

  function gradient(a, b) {
    return (b.y - a.y) / (b.x - a.x);
  }

  for (var j = 1; j < data.columns; j++) {
    xNext = xLast + xStep;
    y = zero - canvas.height / yAxe * (Number(data.table[i][j]) - data.niceMin);
    var curP = {
      x: xNext,
      y: y
    };

    if (j == data.columns - 1) {
      dx2 = 0;
      dy2 = 0;
    } else {
      nexP = {
        x: xNext + xStep,
        y: zero - canvas.height / yAxe * (Number(data.table[i][j + 1]) - data.niceMin)
      };
      m = gradient(preP, nexP);
      dx2 = (nexP.x - curP.x) * -f;
      dy2 = dx2 * m * t;
    }

    if (conf.typeOfLines.value == "1") {
      pathData += lineToPoint(xNext, y);
    } else if (conf.typeOfLines.value == "0") {
      var points = {
        x: xNext,
        y: y,
        c1x: xLast + xStep / 2,
        c1y: yLast,
        c2x: xNext - xStep / 2,
        c2y: y
      };
      pathData += curveToPoint(points);
    } else {
      var _points6 = {
        x: curP.x,
        y: curP.y,
        c1x: preP.x - dx1,
        c1y: preP.y - dy1,
        c2x: curP.x + dx2,
        c2y: curP.y + dy2
      };
      pathData += curveToPoint(_points6);
      dx1 = dx2;
      dy1 = dy2;
      preP = curP;
    }

    xLast = xNext;
    yLast = y;
  }

  var yPrev = zero - canvas.height / yAxe * (Number(data.table[i - 1][data.columns - 1]) - data.niceMin);
  pathData += lineToPoint(xLast, yPrev);
  yLast = yPrev;
  m = 0;
  dx1 = 0;
  dy1 = 0;
  dx2 = 0;
  dy2 = 0;
  preP = {
    x: xLast,
    y: yPrev
  };
  nexP = {};

  for (var _j3 = data.columns - 2; _j3 >= 0; _j3--) {
    xNext = xLast - xStep;
    y = zero - canvas.height / yAxe * (Number(data.table[i - 1][_j3]) - data.niceMin);
    var _curP2 = {
      x: xNext,
      y: y
    };

    if (_j3 == 0) {
      dx2 = 0;
      dy2 = 0;
    } else {
      nexP = {
        x: xNext - xStep,
        y: zero - canvas.height / yAxe * (Number(data.table[i - 1][_j3 - 1]) - data.niceMin)
      };
      m = gradient(preP, nexP);
      dx2 = (nexP.x - _curP2.x) * -f;
      dy2 = dx2 * m * t;
    }

    if (conf.typeOfLines.value == "1") {
      pathData += lineToPoint(xNext, y);
    } else if (conf.typeOfLines.value == "0") {
      var _points7 = {
        x: xNext,
        y: y,
        c1x: xLast - xStep / 2,
        c1y: yLast,
        c2x: xNext + xStep / 2,
        c2y: y
      };
      pathData += curveToPoint(_points7);
    } else {
      var _points8 = {
        x: _curP2.x,
        y: _curP2.y,
        c1x: preP.x - dx1,
        c1y: preP.y - dy1,
        c2x: _curP2.x + dx2,
        c2y: _curP2.y + dy2
      };
      pathData += curveToPoint(_points8);
      dx1 = dx2;
      dy1 = dy2;
      preP = _curP2;
    }

    xLast = xNext;
    yLast = y;
  }

  pathData += " Z";
  var stackedArea = ShapePath.fromSVGPath(pathData);
  stackedArea.style = {
    fills: [conf.colors[colorIndex(i - 1, conf.colors)]],
    borders: [{
      enabled: false
    }]
  };
  stackedArea.name = "Area_" + i;
  group.layers.push(stackedArea);
}
function createVerticalBarChart(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var xStep = canvas.width / data.columns,
      margin = conf.widthOfBars.value * xStep,
      x0 = canvas.x + margin,
      x1,
      y0,
      y1,
      y = 0,
      n = 0,
      yAxe = data.niceMax - data.niceMin,
      zero = canvas.y + canvas.height;
  log(data);

  for (var j = 0; j < data.columns; j++) {
    x0 = x0 + xStep * n;
    x1 = x0 + xStep - 2 * margin;
    y0 = zero - canvas.height / yAxe * (Number(data.table[i - 1][j]) - data.niceMin);
    y1 = zero - canvas.height / yAxe * (Number(data.table[i][j]) - data.niceMin);
    log(x0 + " " + x1 + " " + y0 + " " + y1);
    var pathData = moveToPoint(x0, y0);
    pathData += lineToPoint(x0, y1);
    pathData += lineToPoint(x1, y1);
    pathData += lineToPoint(x1, y0);
    pathData += " Z";
    var bar = ShapePath.fromSVGPath(pathData);
    bar.style = {
      fills: [conf.colors[colorIndex(i - 1, conf.colors)]],
      borders: [{
        enabled: false
      }]
    };
    bar.name = "Bar_" + i + "_" + (j + 1);
    group.layers.push(bar);
    n = n + 1;
    x0 = canvas.x + margin;
  }
}
function createHorizontalBarChart(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var xStep = canvas.height / data.columns,
      margin = conf.widthOfBars.value * xStep,
      y0 = canvas.y + margin,
      x1,
      x0,
      y1,
      y = 0,
      n = 0,
      yAxe = data.niceMax - data.niceMin,
      zero = canvas.x;

  for (var j = 0; j < data.columns; j++) {
    y0 = y0 + xStep * n;
    y1 = y0 + xStep - 2 * margin;
    x0 = zero + canvas.width / yAxe * (Number(data.table[i - 1][j]) - data.niceMin);
    x1 = zero + canvas.width / yAxe * (Number(data.table[i][j]) - data.niceMin);
    var pathData = moveToPoint(x0, y0);
    pathData += lineToPoint(x0, y1);
    pathData += lineToPoint(x1, y1);
    pathData += lineToPoint(x1, y0);
    pathData += " Z";
    var bar = ShapePath.fromSVGPath(pathData);
    bar.style = {
      fills: [conf.colors[colorIndex(i - 1, conf.colors)]],
      borders: [{
        enabled: false
      }]
    };
    bar.name = "Bar_" + i + "_" + (j + 1);
    group.layers.push(bar);
    n = n + 1;
    y0 = canvas.y + margin;
  }
}
function createGroupBarChart(canvas, conf, data, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var xStep = canvas.width / data.columns,
      margin = xStep / (data.rows * (Number(conf.widthOfBars.value) + 1) + 1),
      barWidth = conf.widthOfBars.value * margin,
      x0 = canvas.x + margin,
      x1,
      y0,
      y1,
      y = 0,
      n = 0,
      yAxe = data.niceMax - data.niceMin,
      zero = canvas.y + canvas.height;

  for (var j = 0; j < data.columns; j++) {
    for (var _n = 0; _n < data.rows; _n++) {
      x1 = x0 + barWidth;
      y0 = zero;
      y1 = zero - canvas.height / yAxe * (Number(data.table[_n][j]) - data.niceMin);
      var pathData = moveToPoint(x0, y0);
      pathData += lineToPoint(x0, y1);
      pathData += lineToPoint(x1, y1);
      pathData += lineToPoint(x1, y0);
      pathData += " Z";
      var bar = ShapePath.fromSVGPath(pathData);
      bar.style = {
        fills: [conf.colors[colorIndex(_n, conf.colors)]],
        borders: [{
          enabled: false
        }]
      };
      bar.name = "Bar_" + (_n + 1) + "_" + (j + 1);
      group.layers.push(bar);
      x0 = x0 + barWidth + margin;
    }

    x0 = x0 + margin;
  }
}
function createPieChart(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var radius = canvas.width / 2,
      xCenter = canvas.x + radius,
      yCenter = canvas.y + radius,
      pathData,
      sum = data.table[i].reduce(function (partial_sum, a) {
    return Number(partial_sum) + Number(a);
  }),
      startAngle,
      endAngle,
      multi;

  if (sum == 100) {
    multi = 3.6;
  } else {
    multi = 360 / sum;
  }

  if (conf.sorting.value == "0") {
    var compareNumeric = function compareNumeric(a, b) {
      return b - a;
    };

    var sortedItems = data.table[i];
    sortedItems.sort(compareNumeric);
    data.table[i] = sortedItems;
  }

  if (conf.typeOfCircle.value == "0") {
    startAngle = 0;
    endAngle = data.table[i][0] * multi;
  } else {
    multi = multi / 2;
    startAngle = -90;
    endAngle = Number(data.table[i][0]) * multi - 90;
  }

  for (var j = 0; j < data.columns; j++) {
    var start = polarToCartesian(xCenter, yCenter, radius, endAngle),
        end = polarToCartesian(xCenter, yCenter, radius, startAngle),
        arcSweep = endAngle - startAngle <= 180 ? "0" : "1";
    pathData = ["M", start.x, start.y, "A", radius, radius, 0, arcSweep, 0, end.x, end.y, "L", xCenter, yCenter, "L", start.x, start.y].join(" ");
    var pie = ShapePath.fromSVGPath(pathData);
    pie.style = {
      fills: [conf.colors[colorIndex(j, conf.colors)]],
      borders: [{
        enabled: false
      }]
    };
    pie.name = "Pie_" + j;
    group.layers.push(pie);
    startAngle = startAngle + Number(data.table[i][j]) * multi;
    endAngle = endAngle + Number(data.table[i][j + 1]) * multi;
  }
}
function createDonutChart(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath,
      Style = __webpack_require__(/*! sketch/dom */ "sketch/dom").Style;

  var radius = canvas.width / 2 - conf.thicknessOfDonut.value / 2,
      xCenter = canvas.x + radius + conf.thicknessOfDonut.value / 2,
      yCenter = canvas.y + radius + conf.thicknessOfDonut.value / 2,
      pathData,
      sum = data.table[i].reduce(function (partial_sum, a) {
    return Number(partial_sum) + Number(a);
  }),
      startAngle,
      endAngle,
      multi;

  if (sum == 100) {
    multi = 3.6;
  } else {
    multi = 360 / sum;
  }

  if (conf.sorting.value == "0") {
    var compareNumeric = function compareNumeric(a, b) {
      return b - a;
    };

    var sortedItems = data.table[i];
    sortedItems.sort(compareNumeric);
    data.table[i] = sortedItems;
  }

  if (conf.typeOfCircle.value == "0") {
    startAngle = 0;
    endAngle = data.table[i][0] * multi;
  } else {
    multi = multi / 2;
    startAngle = -90;
    endAngle = Number(data.table[i][0]) * multi - 90;
  }

  for (var j = 0; j < data.columns; j++) {
    var start = polarToCartesian(xCenter, yCenter, radius, endAngle),
        end = polarToCartesian(xCenter, yCenter, radius, startAngle),
        arcSweep = endAngle - startAngle <= 180 ? "0" : "1";
    pathData = ["M", start.x, start.y, "A", radius, radius, 0, arcSweep, 0, end.x, end.y].join(" ");
    var donut = ShapePath.fromSVGPath(pathData);
    donut.style = {
      borders: [{
        color: conf.colors[colorIndex(j, conf.colors)],
        thickness: conf.thicknessOfDonut.value
      }],
      borderOptions: {
        lineEnd: Style.LineEnd.Butt
      }
    };
    donut.name = "Donut_" + j;
    group.layers.push(donut);
    startAngle = startAngle + Number(data.table[i][j]) * multi;
    endAngle = endAngle + Number(data.table[i][j + 1]) * multi;
  }
}
function createProgressChart(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath,
      Style = __webpack_require__(/*! sketch/dom */ "sketch/dom").Style;

  var progress, pathData;

  if (canvas.layerType == "Oval") {
    var radius = canvas.width / 2 - conf.thicknessOfProgress.value / 2,
        xCenter = canvas.x + radius + conf.thicknessOfProgress.value / 2,
        yCenter = canvas.y + radius + conf.thicknessOfProgress.value / 2,
        startAngle,
        endAngle,
        multi = 3.6;
    startAngle = 0;
    endAngle = data.table[i][0] * multi;
    var start = polarToCartesian(xCenter, yCenter, radius, endAngle),
        end = polarToCartesian(xCenter, yCenter, radius, startAngle),
        arcSweep = endAngle - startAngle <= 180 ? "0" : "1";
    pathData = ["M", start.x, start.y, "A", radius, radius, 0, arcSweep, 0, end.x, end.y].join(" ");
    progress = ShapePath.fromSVGPath(pathData);
    progress.style = {
      borders: [{
        color: conf.colors[0],
        thickness: conf.thicknessOfProgress.value
      }]
    };
  } else {
    var xStart = canvas.x,
        xEnd = canvas.x + canvas.width / 100 * data.table[i][0],
        y = canvas.y + canvas.height / 2;

    if (conf.endOfLine.value == "1") {
      xStart = xStart + canvas.height / 2;
    }

    pathData = ["M", xStart, y, "L", xEnd, y].join(" ");
    progress = ShapePath.fromSVGPath(pathData);
    progress.style = {
      borders: [{
        color: conf.colors[0],
        thickness: canvas.height
      }]
    };
  }

  if (conf.endOfLine.value == "0") {
    progress.style.borderOptions.lineEnd = Style.LineEnd.Butt;
  } else {
    progress.style.borderOptions.lineEnd = Style.LineEnd.Round;
  }

  progress.name = "Progress bar";
  group.layers.push(progress);
}
function createSparkline(canvas, conf, data, max, min, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var x0 = canvas.x,
      y = 0,
      yAxe = max - min,
      zero = canvas.y + canvas.height,
      xStep = canvas.width / (data.columns - 1);
  var y0 = zero - canvas.height / yAxe * (Number(data.table[i][0]) - min),
      xLast = x0,
      yLast = y0,
      xNext = 0,
      pathData = moveToPoint(x0, y0);

  for (var j = 1; j < data.columns; j++) {
    xNext = xLast + xStep;
    y = zero - canvas.height / yAxe * (Number(data.table[i][j]) - min);
    pathData += lineToPoint(xNext, y);
    xLast = xNext;
    yLast = y;
  }

  var line = ShapePath.fromSVGPath(pathData);
  line.style = {
    borders: [{
      color: conf.colors[0],
      thickness: conf.thicknessOfLines.value
    }]
  };
  line.name = "Sparkline";
  group.layers.push(line);
  var dot = ShapePath.fromSVGPath(createOval(xLast, yLast, conf.diameterOfDots.value / 2));
  dot.name = "Dot";
  dot.style = {
    fills: [conf.colors[0]],
    borders: [{
      enabled: false
    }]
  };
  group.layers.push(dot);
}
function createScatterPlot(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var x = 0,
      y = 0,
      yAxe = data.yNiceMax - data.yNiceMin,
      xAxe = data.xNiceMax - data.xNiceMin,
      yZero = canvas.y + canvas.height,
      xZero = canvas.x,
      radius = conf.diameterOfDots.value / 2;
  x = xZero + canvas.width / xAxe * (Number(data.table[0][i]) - data.xNiceMin);
  y = yZero - canvas.height / yAxe * (Number(data.table[1][i]) - data.yNiceMin);
  var dot = ShapePath.fromSVGPath(createOval(x, y, radius));
  dot.name = "Dot_" + (i + 1);
  dot.style = {
    fills: [conf.colors[0]],
    borders: [{
      enabled: false
    }]
  };
  group.layers.push(dot);
}
function createCandlestickChart(canvas, conf, data, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var yAxe = data.niceMax - data.niceMin,
      zero = canvas.y + canvas.height,
      step = canvas.width / data.columns,
      margin = (1 - Number(conf.widthOfBoxes.value)) / 2 * step,
      x0 = canvas.x + margin,
      y0 = 0,
      x1 = 0,
      y1 = 0,
      x0line = canvas.x + step / 2,
      y0line = 0,
      y1line = 0,
      n = 0,
      candleColor;

  for (var z = 0; z < data.columns; z++) {
    x0 = x0 + step * n;
    x1 = x0 + step - 2 * margin;
    x0line = x0line + step * n;

    if (data.table[1][z] > data.table[2][z]) {
      y0 = zero - canvas.height / yAxe * (Number(data.table[2][z]) - data.niceMin);
      y1 = zero - canvas.height / yAxe * (Number(data.table[1][z]) - data.niceMin);
      y0line = zero - canvas.height / yAxe * (Number(data.table[3][z]) - data.niceMin);
      y1line = zero - canvas.height / yAxe * (Number(data.table[0][z]) - data.niceMin);
      candleColor = conf.colors[0];
    } else {
      y0 = zero - canvas.height / yAxe * (Number(data.table[1][z]) - data.niceMin);
      y1 = zero - canvas.height / yAxe * (Number(data.table[2][z]) - data.niceMin);
      y0line = zero - canvas.height / yAxe * (Number(data.table[3][z]) - data.niceMin);
      y1line = zero - canvas.height / yAxe * (Number(data.table[0][z]) - data.niceMin);
      candleColor = conf.colors[1];
    }

    var lineData = moveToPoint(x0line, y0line);
    lineData += lineToPoint(x0line, y1line);
    var line = ShapePath.fromSVGPath(lineData);
    line.style = {
      borders: [{
        color: candleColor,
        thickness: 1
      }]
    };
    line.name = "Line";
    group.layers.push(line);
    var barData = moveToPoint(x0, y0);
    barData += lineToPoint(x0, y1);
    barData += lineToPoint(x1, y1);
    barData += lineToPoint(x1, y0);
    barData += " Z";
    var bar = ShapePath.fromSVGPath(barData);
    bar.style = {
      fills: [candleColor],
      borders: [{
        enabled: false
      }]
    };
    bar.name = "Candle";
    group.layers.push(bar);
    n = 1;
  }
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/promise-polyfill/lib/index.js */ "./node_modules/promise-polyfill/lib/index.js"), __webpack_require__(/*! ./node_modules/sketch-polyfill-fetch/lib/index.js */ "./node_modules/sketch-polyfill-fetch/lib/index.js")))

/***/ }),

/***/ "./src/nicenum.js":
/*!************************!*\
  !*** ./src/nicenum.js ***!
  \************************/
/*! exports provided: calculateNiceNum */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "calculateNiceNum", function() { return calculateNiceNum; });
function calculateNiceNum(minNum, maxNum) {
  // Nice max and min functions
  var minPoint,
      maxPoint,
      maxTicks = 10,
      range,
      tickSpacing,
      niceMin,
      niceMax;
  /**
   * Instantiates a new instance of the NiceScale class.
   *
   *  min the minimum data point on the axis
   *  max the maximum data point on the axis
   */

  function niceScale(min, max) {
    minPoint = min;
    maxPoint = max;
    calculate();
    return {
      niceMinimum: niceMin,
      niceMaximum: niceMax
    };
  }
  /**
   * Calculate and update values for tick spacing and nice
   * minimum and maximum data points on the axis.
   */


  function calculate() {
    range = niceNum(maxPoint - minPoint, false);
    tickSpacing = niceNum(range / (maxTicks - 1), true);
    niceMin = Math.floor(minPoint / tickSpacing) * tickSpacing;
    niceMax = Math.ceil(maxPoint / tickSpacing) * tickSpacing;
  }
  /**
   * Returns a "nice" number approximately equal to range Rounds
   * the number if round = true Takes the ceiling if round = false.
   *
   *  localRange the data range
   *  round whether to round the result
   *  a "nice" number to be used for the data range
   */


  function niceNum(localRange, round) {
    var exponent;
    /** exponent of localRange */

    var fraction;
    /** fractional part of localRange */

    var niceFraction;
    /** nice, rounded fraction */

    exponent = Math.floor(Math.log10(localRange));
    fraction = localRange / Math.pow(10, exponent);

    if (round) {
      if (fraction < 1.5) niceFraction = 1;else if (fraction < 3) niceFraction = 2;else if (fraction < 7) niceFraction = 5;else niceFraction = 10;
    } else {
      if (fraction <= 1) niceFraction = 1;else if (fraction <= 2) niceFraction = 2;else if (fraction <= 5) niceFraction = 5;else niceFraction = 10;
    }

    return niceFraction * Math.pow(10, exponent);
  }

  return niceScale(minNum, maxNum);
}

/***/ }),

/***/ "./src/update.js":
/*!***********************!*\
  !*** ./src/update.js ***!
  \***********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _nicenum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./nicenum */ "./src/nicenum.js");
/* harmony import */ var _common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./common */ "./src/common.js");
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }



/* harmony default export */ __webpack_exports__["default"] = (function (context) {
  var UI = __webpack_require__(/*! sketch/ui */ "sketch/ui"),
      Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings"),
      Group = __webpack_require__(/*! sketch/dom */ "sketch/dom").Group,
      fetch = __webpack_require__(/*! sketch-polyfill-fetch */ "./node_modules/sketch-polyfill-fetch/lib/index.js");

  function updateChart(canvas, prevSettings, chartType) {
    var dataFromPopup = prevSettings,
        stringSettings = JSON.stringify(prevSettings),
        conf = dataFromPopup.settings,
        data;

    if (chartType == "Line chart") {
      canvas.forEach(function (canvas) {
        var chartGroup = new Group({
          name: 'Line chart',
          parent: canvas.parent
        });
        chartGroup.layers.push(canvas.layer);
        Settings.setLayerSettingForKey(chartGroup, 'localConf', dataFromPopup);

        if (dataFromPopup.data.selected == "random") {
          var random = dataFromPopup.data.random;
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["createRandomData"])(random.categories.value, random.items.value, random.min, random.max, random.randType, "linechart");
        } else if (dataFromPopup.data.selected == "table") {
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["processData"])(dataFromPopup.data.csv.data, dataFromPopup.data.csv.headers);
        } else {
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["processJSON"])(dataFromPopup.data.json.data, dataFromPopup.data.json.keys, dataFromPopup.data.json.header);
        }

        if (canvas.startNum != "false") {
          data.min = canvas.startNum;
        }

        var niceScales = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(data.min, data.max);
        data.niceMax = niceScales.niceMaximum;
        data.niceMin = niceScales.niceMinimum;

        if (conf.grid.value != "0") {
          Object(_common__WEBPACK_IMPORTED_MODULE_1__["createGrid"])(conf, canvas, data, chartGroup);
        }

        if (conf.labels.value != "0") {
          Object(_common__WEBPACK_IMPORTED_MODULE_1__["createLabels"])(conf, canvas, data, chartGroup);
        }

        for (var i = 0; i < data.rows; i++) {
          Object(_common__WEBPACK_IMPORTED_MODULE_1__["createLineChart"])(canvas, conf, data, i, chartGroup);
        }

        if (conf.dots.value != "0") {
          for (var _i = 0; _i < data.rows; _i++) {
            Object(_common__WEBPACK_IMPORTED_MODULE_1__["createDots"])(canvas, conf, data, _i, chartGroup);
          }
        }

        chartGroup.adjustToFit();
        dataFromPopup = JSON.parse(stringSettings);
      });
    } else if (chartType == "Area chart") {
      canvas.forEach(function (canvas) {
        var chartGroup = new Group({
          name: 'Area chart',
          parent: canvas.parent
        });
        chartGroup.layers.push(canvas.layer);
        Settings.setLayerSettingForKey(chartGroup, 'localConf', dataFromPopup);

        if (dataFromPopup.data.selected == "random") {
          var random = dataFromPopup.data.random;
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["createRandomData"])(random.categories.value, random.items.value, random.min, random.max, random.randType, "areachart");
        } else if (dataFromPopup.data.selected == "table") {
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["processData"])(dataFromPopup.data.csv.data, dataFromPopup.data.csv.headers);
        } else {
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["processJSON"])(dataFromPopup.data.json.data, dataFromPopup.data.json.keys, dataFromPopup.data.json.header);
        }

        if (canvas.startNum != "false") {
          data.min = canvas.startNum;
        }

        var niceScales = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(data.min, data.max);
        data.niceMax = niceScales.niceMaximum;
        data.niceMin = niceScales.niceMinimum;

        if (conf.grid.value != "0") {
          Object(_common__WEBPACK_IMPORTED_MODULE_1__["createGrid"])(conf, canvas, data, chartGroup);
        }

        if (conf.labels.value != "0") {
          Object(_common__WEBPACK_IMPORTED_MODULE_1__["createLabels"])(conf, canvas, data, chartGroup);
        }

        for (var i = 0; i < data.rows; i++) {
          Object(_common__WEBPACK_IMPORTED_MODULE_1__["createAreaChart"])(canvas, conf, data, i, chartGroup);
        }

        chartGroup.adjustToFit();
        dataFromPopup = JSON.parse(stringSettings);
      });
    } else if (chartType == "Stacked area chart") {
      canvas.forEach(function (canvas) {
        var chartGroup = new Group({
          name: 'Stacked area chart',
          parent: canvas.parent
        });
        chartGroup.layers.push(canvas.layer);
        Settings.setLayerSettingForKey(chartGroup, 'localConf', dataFromPopup);

        if (dataFromPopup.data.selected == "random") {
          var random = dataFromPopup.data.random;
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["createRandomData"])(random.categories.value, random.items.value, random.min, random.max, random.randType, "stacked");
        } else if (dataFromPopup.data.selected == "table") {
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["processData"])(dataFromPopup.data.csv.data, dataFromPopup.data.csv.headers);
        } else {
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["processJSON"])(dataFromPopup.data.json.data, dataFromPopup.data.json.keys, dataFromPopup.data.json.header);
        } // Prepare data for stacked rendering


        for (var i = 1; i < data.rows; i++) {
          for (var j = 0; j < data.columns; j++) {
            data.table[i][j] = Number(data.table[i - 1][j]) + Number(data.table[i][j]);
          }
        } // Insert first zero-array


        var zeroArray = new Array();

        for (var _i2 = 0; _i2 < data.columns; _i2++) {
          zeroArray[_i2] = 0;
        }

        ;
        data.table.unshift(zeroArray);
        data.rows = data.rows + 1; // New max, min and nice

        data.max = Math.max.apply(Math, _toConsumableArray(data.table[data.rows - 1]));
        data.min = Math.min.apply(Math, _toConsumableArray(data.table[data.rows - 1]));
        var niceScales = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(data.min, data.max);
        data.niceMax = niceScales.niceMaximum;
        data.niceMin = niceScales.niceMinimum;

        if (data.rows > 2) {
          data.niceMin = 0;
        } else {
          if (data.niceMin > 0) {
            data.niceMin = 0;
          }
        }

        if (conf.grid.value != "0") {
          Object(_common__WEBPACK_IMPORTED_MODULE_1__["createGrid"])(conf, canvas, data, chartGroup);
        }

        if (conf.labels.value != "0") {
          Object(_common__WEBPACK_IMPORTED_MODULE_1__["createLabels"])(conf, canvas, data, chartGroup);
        }

        for (var _i3 = 1; _i3 < data.rows; _i3++) {
          Object(_common__WEBPACK_IMPORTED_MODULE_1__["createStackedAreaChart"])(canvas, conf, data, _i3, chartGroup);
        }

        chartGroup.adjustToFit();
        dataFromPopup = JSON.parse(stringSettings);
      });
    } else if (chartType == "Vertical bar chart") {
      canvas.forEach(function (canvas) {
        var chartGroup = new Group({
          name: 'Vertical bar chart',
          parent: canvas.parent
        });
        chartGroup.layers.push(canvas.layer);
        Settings.setLayerSettingForKey(chartGroup, 'localConf', dataFromPopup);

        if (dataFromPopup.data.selected == "random") {
          var random = dataFromPopup.data.random;
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["createRandomData"])(random.categories.value, random.items.value, random.min, random.max, random.randType, "stacked");
        } else if (dataFromPopup.data.selected == "table") {
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["processData"])(dataFromPopup.data.csv.data, dataFromPopup.data.csv.headers);
        } else {
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["processJSON"])(dataFromPopup.data.json.data, dataFromPopup.data.json.keys, dataFromPopup.data.json.header);
        } // Prepare data for stacked rendering


        for (var i = 1; i < data.rows; i++) {
          for (var j = 0; j < data.columns; j++) {
            data.table[i][j] = Number(data.table[i - 1][j]) + Number(data.table[i][j]);
          }
        } // Insert first zero-array


        var zeroArray = new Array();

        for (var _i4 = 0; _i4 < data.columns; _i4++) {
          zeroArray[_i4] = 0;
        }

        ;
        data.table.unshift(zeroArray);
        data.rows = data.rows + 1; // New max, min and nice

        data.max = Math.max.apply(Math, _toConsumableArray(data.table[data.rows - 1]));
        data.min = Math.min.apply(Math, _toConsumableArray(data.table[data.rows - 1]));
        var niceScales = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(data.min, data.max);
        data.niceMax = niceScales.niceMaximum;
        data.niceMin = niceScales.niceMinimum;

        if (data.rows > 2) {
          data.niceMin = 0;
        } else {
          if (data.niceMin > 0) {
            data.niceMin = 0;
          }
        }

        if (conf.grid.value != "0") {
          Object(_common__WEBPACK_IMPORTED_MODULE_1__["createBarGrid"])(conf, canvas, data, chartGroup);
        }

        if (conf.labels.value != "0") {
          Object(_common__WEBPACK_IMPORTED_MODULE_1__["createBarLabels"])(conf, canvas, data, chartGroup);
        }

        for (var _i5 = 1; _i5 < data.rows; _i5++) {
          Object(_common__WEBPACK_IMPORTED_MODULE_1__["createVerticalBarChart"])(canvas, conf, data, _i5, chartGroup);
        }

        chartGroup.adjustToFit();
        dataFromPopup = JSON.parse(stringSettings);
      });
    } else if (chartType == "Horizontal bar chart") {
      canvas.forEach(function (canvas) {
        var chartGroup = new Group({
          name: 'Horizontal bar chart',
          parent: canvas.parent
        });
        chartGroup.layers.push(canvas.layer);
        Settings.setLayerSettingForKey(chartGroup, 'localConf', dataFromPopup);

        if (dataFromPopup.data.selected == "random") {
          var random = dataFromPopup.data.random;
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["createRandomData"])(random.categories.value, random.items.value, random.min, random.max, random.randType, "stacked");
        } else if (dataFromPopup.data.selected == "table") {
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["processData"])(dataFromPopup.data.csv.data, dataFromPopup.data.csv.headers);
        } else {
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["processJSON"])(dataFromPopup.data.json.data, dataFromPopup.data.json.keys, dataFromPopup.data.json.header);
        } // Prepare data for stacked rendering


        for (var i = 1; i < data.rows; i++) {
          for (var j = 0; j < data.columns; j++) {
            data.table[i][j] = Number(data.table[i - 1][j]) + Number(data.table[i][j]);
          }
        } // Insert first zero-array


        var zeroArray = new Array();

        for (var _i6 = 0; _i6 < data.columns; _i6++) {
          zeroArray[_i6] = 0;
        }

        ;
        data.table.unshift(zeroArray);
        data.rows = data.rows + 1; // New max, min and nice

        data.max = Math.max.apply(Math, _toConsumableArray(data.table[data.rows - 1]));
        data.min = Math.min.apply(Math, _toConsumableArray(data.table[data.rows - 1]));
        var niceScales = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(data.min, data.max);
        data.niceMax = niceScales.niceMaximum;
        data.niceMin = niceScales.niceMinimum;

        if (data.rows > 2) {
          data.niceMin = 0;
        } else {
          if (data.niceMin > 0) {
            data.niceMin = 0;
          }
        }

        if (conf.grid.value != "0") {
          Object(_common__WEBPACK_IMPORTED_MODULE_1__["createHorizontalGrid"])(conf, canvas, data, chartGroup);
        }

        if (conf.labels.value != "0") {
          Object(_common__WEBPACK_IMPORTED_MODULE_1__["createHorizontalLabels"])(conf, canvas, data, chartGroup);
        }

        for (var _i7 = 1; _i7 < data.rows; _i7++) {
          Object(_common__WEBPACK_IMPORTED_MODULE_1__["createHorizontalBarChart"])(canvas, conf, data, _i7, chartGroup);
        }

        chartGroup.adjustToFit();
        dataFromPopup = JSON.parse(stringSettings);
      });
    } else if (chartType == "Grouped bar chart") {
      canvas.forEach(function (canvas) {
        var chartGroup = new Group({
          name: 'Grouped bar chart',
          parent: canvas.parent
        });
        chartGroup.layers.push(canvas.layer);
        Settings.setLayerSettingForKey(chartGroup, 'localConf', dataFromPopup);

        if (dataFromPopup.data.selected == "random") {
          var random = dataFromPopup.data.random;
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["createRandomData"])(random.categories.value, random.items.value, random.min, random.max, random.randType, "stacked");
        } else if (dataFromPopup.data.selected == "table") {
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["processData"])(dataFromPopup.data.csv.data, dataFromPopup.data.csv.headers);
        } else {
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["processJSON"])(dataFromPopup.data.json.data, dataFromPopup.data.json.keys, dataFromPopup.data.json.header);
        }

        var niceScales = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(data.min, data.max);
        data.niceMax = niceScales.niceMaximum;
        data.niceMin = niceScales.niceMinimum;

        if (canvas.startNum != "false") {
          data.min = canvas.startNum;
        }

        if (conf.grid.value != "0") {
          Object(_common__WEBPACK_IMPORTED_MODULE_1__["createBarGrid"])(conf, canvas, data, chartGroup);
        }

        if (conf.labels.value != "0") {
          Object(_common__WEBPACK_IMPORTED_MODULE_1__["createBarLabels"])(conf, canvas, data, chartGroup);
        }

        Object(_common__WEBPACK_IMPORTED_MODULE_1__["createGroupBarChart"])(canvas, conf, data, chartGroup);
        chartGroup.adjustToFit();
        dataFromPopup = JSON.parse(stringSettings);
      });
    } else if (chartType == "Stream graph") {
      canvas.forEach(function (canvas) {
        var chartGroup = new Group({
          name: 'Stream graph',
          parent: canvas.parent
        });
        chartGroup.layers.push(canvas.layer);
        Settings.setLayerSettingForKey(chartGroup, 'localConf', dataFromPopup);

        if (dataFromPopup.data.selected == "random") {
          var random = dataFromPopup.data.random;
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["createRandomData"])(random.categories.value, random.items.value, random.min, random.max, random.randType, "stacked");
        } else if (dataFromPopup.data.selected == "table") {
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["processData"])(dataFromPopup.data.csv.data, dataFromPopup.data.csv.headers);
        } else {
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["processJSON"])(dataFromPopup.data.json.data, dataFromPopup.data.json.keys, dataFromPopup.data.json.header);
        } // Prepare data for stacked rendering


        for (var i = 1; i < data.rows; i++) {
          for (var j = 0; j < data.columns; j++) {
            data.table[i][j] = Number(data.table[i - 1][j]) + Number(data.table[i][j]);
          }
        } // Insert first zero-array


        var zeroArray = new Array();

        for (var _i8 = 0; _i8 < data.columns; _i8++) {
          zeroArray[_i8] = 0;
        }

        ;
        data.table.unshift(zeroArray);
        data.rows = data.rows + 1; // New max, min and nice

        data.max = Math.max.apply(Math, _toConsumableArray(data.table[data.rows - 1]));
        data.min = Math.min.apply(Math, _toConsumableArray(data.table[data.rows - 1]));
        var niceScales = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(data.min, data.max);
        data.niceMax = niceScales.niceMaximum;
        data.niceMin = niceScales.niceMinimum;

        if (data.rows > 2) {
          data.niceMin = 0;
        } else {
          if (data.niceMin > 0) {
            data.niceMin = 0;
          }
        }

        for (var _i9 = 0; _i9 < data.rows; _i9++) {
          for (var _j = 0; _j < data.columns; _j++) {
            data.table[_i9][_j] = Number(data.table[_i9][_j]) + (data.niceMax - Number(data.table[data.rows - 1][_j])) / 2;
          }
        }

        if (conf.grid.value != "0") {
          Object(_common__WEBPACK_IMPORTED_MODULE_1__["createGrid"])(conf, canvas, data, chartGroup);
        }

        if (conf.labels.value != "0") {
          Object(_common__WEBPACK_IMPORTED_MODULE_1__["createLabels"])(conf, canvas, data, chartGroup);
        }

        for (var _i10 = 1; _i10 < data.rows; _i10++) {
          Object(_common__WEBPACK_IMPORTED_MODULE_1__["createStreamGraph"])(canvas, conf, data, _i10, chartGroup);
        }

        chartGroup.adjustToFit();
        dataFromPopup = JSON.parse(stringSettings);
      });
    } else if (chartType == "Scatter plot") {
      canvas.forEach(function (canvas) {
        var chartGroup = new Group({
          name: 'Scatter plot',
          parent: canvas.parent
        });
        chartGroup.layers.push(canvas.layer);
        Settings.setLayerSettingForKey(chartGroup, 'localConf', dataFromPopup);

        if (dataFromPopup.data.selected == "random") {
          var random = dataFromPopup.data.random;
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["createRandomData"])(random.categories.value, random.items.value, random.min, random.max, random.randType, "scatterplot");
        } else if (dataFromPopup.data.selected == "table") {
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["processData"])(dataFromPopup.data.csv.data, dataFromPopup.data.csv.headers);
        } else {
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["processJSON"])(dataFromPopup.data.json.data, dataFromPopup.data.json.keys, dataFromPopup.data.json.header);
        }

        var xMin = Math.min.apply(Math, _toConsumableArray(data.table[0])),
            xMax = Math.max.apply(Math, _toConsumableArray(data.table[0])),
            yMin = Math.min.apply(Math, _toConsumableArray(data.table[1])),
            yMax = Math.max.apply(Math, _toConsumableArray(data.table[1]));

        if (canvas.startNum != "false") {
          xMin = canvas.startNum;
          yMin = canvas.startNum;
        }

        var xNiceScales = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(xMin, xMax),
            yNiceScales = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(yMin, yMax);
        data.xNiceMax = xNiceScales.niceMaximum;
        data.xNiceMin = xNiceScales.niceMinimum;
        data.yNiceMax = yNiceScales.niceMaximum;
        data.yNiceMin = yNiceScales.niceMinimum;

        if (conf.grid.value != "0") {
          Object(_common__WEBPACK_IMPORTED_MODULE_1__["createPlotGrid"])(conf, canvas, data, chartGroup);
        }

        if (conf.labels.value != "0") {
          Object(_common__WEBPACK_IMPORTED_MODULE_1__["createPlotLabels"])(conf, canvas, data, chartGroup);
        }

        for (var i = 0; i < data.columns; i++) {
          Object(_common__WEBPACK_IMPORTED_MODULE_1__["createScatterPlot"])(canvas, conf, data, i, chartGroup);
        }

        chartGroup.adjustToFit();
        dataFromPopup = JSON.parse(stringSettings);
      });
    } else if (chartType == "Candlestick chart") {
      canvas.forEach(function (canvas) {
        var chartGroup = new Group({
          name: 'Candlestick chart',
          parent: canvas.parent
        });
        chartGroup.layers.push(canvas.layer);
        Settings.setLayerSettingForKey(chartGroup, 'localConf', dataFromPopup);

        if (dataFromPopup.data.selected == "random") {
          var random = dataFromPopup.data.random;
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["createRandomData"])(random.categories.value, random.items.value, random.min, random.max, random.randType, "candle");
        } else if (dataFromPopup.data.selected == "table") {
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["processData"])(dataFromPopup.data.csv.data, dataFromPopup.data.csv.headers);
        } else {
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["processJSON"])(dataFromPopup.data.json.data, dataFromPopup.data.json.keys, dataFromPopup.data.json.header);
        }

        var maxLine = Math.max.apply(Math, _toConsumableArray(data.table[0])),
            minLine = Math.min.apply(Math, _toConsumableArray(data.table[3]));

        if (canvas.startNum != "false") {
          minLine = canvas.startNum;
        }

        var niceScales = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(minLine, maxLine);
        data.niceMax = niceScales.niceMaximum;
        data.niceMin = niceScales.niceMinimum;

        if (conf.grid.value != "0") {
          Object(_common__WEBPACK_IMPORTED_MODULE_1__["createCandleGrid"])(conf, canvas, data, chartGroup);
        }

        if (conf.labels.value != "0") {
          Object(_common__WEBPACK_IMPORTED_MODULE_1__["createCandleLabels"])(conf, canvas, data, chartGroup);
        }

        Object(_common__WEBPACK_IMPORTED_MODULE_1__["createCandlestickChart"])(canvas, conf, data, chartGroup);
        chartGroup.adjustToFit();
        dataFromPopup = JSON.parse(stringSettings);
      });
    } else if (chartType == "Pie chart") {
      canvas.forEach(function (canvas, index) {
        var chartGroup = new Group({
          name: 'Pie chart',
          parent: canvas.parent
        });
        chartGroup.layers.push(canvas.layer);
        Settings.setLayerSettingForKey(chartGroup, 'localConf', dataFromPopup);

        if (dataFromPopup.data.selected == "random") {
          var random = dataFromPopup.data.random;
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["createRandomData"])(random.categories.value, random.items.value, random.min, random.max, random.randType, "circle");
        } else if (dataFromPopup.data.selected == "table") {
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["processData"])(dataFromPopup.data.csv.data, dataFromPopup.data.csv.headers);
        } else {
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["processJSON"])(dataFromPopup.data.json.data, dataFromPopup.data.json.keys, dataFromPopup.data.json.header);
        }

        Object(_common__WEBPACK_IMPORTED_MODULE_1__["createPieChart"])(canvas, conf, data, index, chartGroup);
        chartGroup.adjustToFit();
        dataFromPopup = JSON.parse(stringSettings);
      });
    } else if (chartType == "Donut chart") {
      canvas.forEach(function (canvas, index) {
        var chartGroup = new Group({
          name: 'Donut chart',
          parent: canvas.parent
        });
        chartGroup.layers.push(canvas.layer);
        Settings.setLayerSettingForKey(chartGroup, 'localConf', dataFromPopup);

        if (dataFromPopup.data.selected == "random") {
          var random = dataFromPopup.data.random;
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["createRandomData"])(random.categories.value, random.items.value, random.min, random.max, random.randType, "circle");
        } else if (dataFromPopup.data.selected == "table") {
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["processData"])(dataFromPopup.data.csv.data, dataFromPopup.data.csv.headers);
        } else {
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["processJSON"])(dataFromPopup.data.json.data, dataFromPopup.data.json.keys, dataFromPopup.data.json.header);
        }

        Object(_common__WEBPACK_IMPORTED_MODULE_1__["createDonutChart"])(canvas, conf, data, index, chartGroup);
        chartGroup.adjustToFit();
        dataFromPopup = JSON.parse(stringSettings);
      });
    } else if (chartType == "Progress chart") {
      canvas.forEach(function (canvas, index) {
        var chartGroup = new Group({
          name: 'Progress chart',
          parent: canvas.parent
        });
        chartGroup.layers.push(canvas.layer);
        Settings.setLayerSettingForKey(chartGroup, 'localConf', dataFromPopup);

        if (dataFromPopup.data.selected == "random") {
          var random = dataFromPopup.data.random;
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["createRandomData"])(random.categories.value, random.items.value, random.min, random.max, random.randType, "circle");
        } else if (dataFromPopup.data.selected == "table") {
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["processData"])(dataFromPopup.data.csv.data, dataFromPopup.data.csv.headers);
        } else {
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["processJSON"])(dataFromPopup.data.json.data, dataFromPopup.data.json.keys, dataFromPopup.data.json.header);
        }

        Object(_common__WEBPACK_IMPORTED_MODULE_1__["createProgressChart"])(canvas, conf, data, index, chartGroup);
        chartGroup.adjustToFit();
        dataFromPopup = JSON.parse(stringSettings);
      });
    } else if (chartType == "Sparkline") {
      canvas.forEach(function (canvas, index) {
        var chartGroup = new Group({
          name: 'Sparkline',
          parent: canvas.parent
        });
        chartGroup.layers.push(canvas.layer);
        Settings.setLayerSettingForKey(chartGroup, 'localConf', dataFromPopup);

        if (dataFromPopup.data.selected == "random") {
          var random = dataFromPopup.data.random;
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["createRandomData"])(random.categories.value, random.items.value, random.min, random.max, random.randType, "linechart");
        } else if (dataFromPopup.data.selected == "table") {
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["processData"])(dataFromPopup.data.csv.data, dataFromPopup.data.csv.headers);
        } else {
          data = Object(_common__WEBPACK_IMPORTED_MODULE_1__["processJSON"])(dataFromPopup.data.json.data, dataFromPopup.data.json.keys, dataFromPopup.data.json.header);
        }

        var max = Math.max.apply(Math, _toConsumableArray(data.table[index])),
            min = Math.min.apply(Math, _toConsumableArray(data.table[index])),
            niceScales = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(min, max);
        max = niceScales.niceMaximum;
        min = niceScales.niceMinimum;

        if (canvas.startNum != "false") {
          min = canvas.startNum;
        }

        Object(_common__WEBPACK_IMPORTED_MODULE_1__["createSparkline"])(canvas, conf, data, max, min, index, chartGroup);
        chartGroup.adjustToFit();
        dataFromPopup = JSON.parse(stringSettings);
      });
    }
  } // Get Canvas


  var updatable = Object(_common__WEBPACK_IMPORTED_MODULE_1__["chartUpdatable"])(context);

  if (updatable) {
    var canvasObj = Object(_common__WEBPACK_IMPORTED_MODULE_1__["getCanvas"])(context),
        canvas = canvasObj[0],
        error = canvasObj[1];

    if (canvas[0].conf.data.selected == "random") {
      updateChart(canvas, canvas[0].conf, canvas[0].conf.data.chartName);
      UI.message('🎉 Chart updated!');
    } else if (canvas[0].conf.data.selected == "table" && canvas[0].conf.data.csv.gsLink != null) {
      fetch(canvas[0].conf.data.csv.gsLink).then(function (res) {
        return {
          json: res.json()._value
        };
      }).then(function (jsonObject) {
        canvas[0].conf.data.csv.data = jsonObject.json.values;
        updateChart(canvas, canvas[0].conf, canvas[0].conf.data.chartName);
        UI.message('🎉 Chart updated!');
      });
    } else if (canvas[0].conf.data.selected == "json" && canvas[0].conf.data.json.jsonLink != null) {
      fetch(canvas[0].conf.data.json.jsonLink).then(function (res) {
        return {
          json: res.json()._value
        };
      }).then(function (jsonObject) {
        canvas[0].conf.data.json.data = jsonObject.json;
        updateChart(canvas, canvas[0].conf, canvas[0].conf.data.chartName);
        UI.message('🎉 Chart updated!');
      });
    }
  } else {
    UI.message('Chart with this data is not updatable');
  }
});

/***/ }),

/***/ "buffer":
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("buffer");

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ }),

/***/ "sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ }),

/***/ "sketch/settings":
/*!**********************************!*\
  !*** external "sketch/settings" ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/settings");

/***/ }),

/***/ "sketch/ui":
/*!****************************!*\
  !*** external "sketch/ui" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/ui");

/***/ })

/******/ });
  if (key === 'default' && typeof exports === 'function') {
    exports(context);
  } else {
    exports[key](context);
  }
}
that['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=update.js.map